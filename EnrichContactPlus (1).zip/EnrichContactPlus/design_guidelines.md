# Design Guidelines: Contact Enrichment Web Resource

## Design Approach

**Selected Approach:** Design System - Fluent Design (Microsoft)

**Justification:** As an embedded tool within Microsoft Power Platform, Fluent Design ensures visual consistency with the PowerApps ecosystem while providing clear patterns for enterprise productivity applications. This utility-focused tool prioritizes efficiency, clarity, and information hierarchy over visual storytelling.

**Key Principles:**
1. Clarity and efficiency in dense information display
2. Seamless integration within PowerApps Contact form
3. Progressive disclosure of enrichment workflow
4. Clear status communication and actionable feedback

---

## Typography

**Font Family:** Segoe UI (system default for Microsoft ecosystem)

**Hierarchy:**
- Page Title: 24px, Semibold (600)
- Section Headers: 18px, Semibold (600)
- Subsection Headers: 16px, Medium (500)
- Body Text: 14px, Regular (400)
- Labels/Captions: 12px, Regular (400)
- Microcopy/Helper Text: 11px, Regular (400)

**Line Height:** 1.5 for body text, 1.3 for headings

---

## Layout System

**Spacing Primitives:** Tailwind units of 2, 3, 4, 6, and 8
- Micro spacing (icons, tight elements): p-2, gap-2
- Standard element spacing: p-4, gap-4, mb-4
- Section spacing: p-6, mb-6
- Major section breaks: p-8, mb-8

**Container Strategy:**
- Main container: max-w-6xl with p-6
- Card components: p-4 or p-6 based on content density
- Form groups: mb-4 between fields, mb-6 between sections

**Grid System:**
- API Configuration: Single column stack
- Current Contact Data: 2-column grid (md:grid-cols-2) for field display
- Enrichment Results: Multi-column cards (md:grid-cols-2 lg:grid-cols-3) for source results
- Data Selection Interface: Single column with clear checkboxes

---

## Component Library

### Navigation & Controls

**Tab Navigation** (Enrichment Modes):
- Horizontal tab bar with three options: "Force Run All" | "Waterfall" | "Select Source"
- Active state: Bottom border indicator (3px)
- Spacing: px-6, py-3 per tab

**Radio Button Groups** (Provider Selection):
- Vertical stack with clear labels
- Radio circles with checkmark on selection
- Spacing: gap-3 between options

**Action Buttons:**
- Primary CTA: Full-width or inline-flex with px-6, py-3
- Secondary actions: px-4, py-2
- Icon buttons: 40px × 40px clickable area
- Button text: 14px, Medium (500)

### Forms & Inputs

**Text Input Fields:**
- Height: h-10 (40px)
- Padding: px-4
- Border: 1px solid with rounded-md
- Label above: mb-2 spacing
- Helper text below: mt-1, text-11px

**API Key Input:**
- Grouped by provider name (bold label, 14px)
- Text input with password toggle icon
- "Test Connection" button inline or below
- Status indicator (success/error) with icon

**Contact Data Display:**
- Read-only field pairs in 2-column grid
- Label: 12px, uppercase, Medium (500)
- Value: 14px, Regular (400)
- LinkedIn profile as clickable link with external icon

### Data Display

**Provider Result Cards:**
- Card container: rounded-lg with subtle border
- Header: Provider name + logo space (if available) + status badge
- Content area: List of discovered emails/phones
- Each result item: checkbox + value + copy button
- Footer: Timestamp + confidence indicator (if applicable)

**Status Badges:**
- Small pill shape: px-3, py-1, rounded-full
- Text: 11px, Medium (500)
- States: Loading, Success, Error, No Results

**Results List:**
- Items with gap-2 vertical spacing
- Each item: Checkbox (16px) + Label (14px) + Icon button (copy)
- Indent: pl-6 for sub-items or grouped data

### Information Architecture

**Section Structure:**
1. **API Configuration Panel** (Collapsible accordion):
   - Header with chevron icon
   - Form fields stack with gap-4
   - Save button at bottom

2. **Current Contact Information**:
   - Card with p-6
   - 2-column grid for fields
   - Clear visual separation from enrichment area

3. **Enrichment Controls**:
   - Mode selector tabs
   - Provider checkboxes (if "Select Source" mode)
   - Primary "Run Enrichment" button with loading state

4. **Results Display**:
   - Grid of provider cards
   - Each card shows: Mobile numbers section + Emails section
   - Clear empty states with helpful messaging

5. **Executive Assistant Search**:
   - Separate card/section with p-6
   - "Search for EA" trigger button
   - Results display: EA Name, Email, Phone in structured format
   - Conditional display (only when EA field is blank)

6. **Apply Changes Footer**:
   - Sticky/fixed bottom bar
   - Selected items count
   - "Copy to Contact" primary button
   - "Clear Selection" secondary link

### Loading & Status States

**Progress Indicators:**
- Spinner: 20px for inline, 32px for full-section loading
- Linear progress bar: h-1 (4px) for multi-step processes
- Provider-specific status: Per-card loading with shimmer effect

**Empty States:**
- Icon (48px) centered
- Message text: 14px, centered, max-w-md
- Action button below message

**Error States:**
- Error icon with alert styling
- Error message: 14px with specific guidance
- Retry action button

---

## Accessibility Standards

- All interactive elements: min 44px touch target
- Form labels: Explicit association with inputs
- Status messages: aria-live regions for dynamic updates
- Keyboard navigation: Tab order follows logical flow
- Focus indicators: Visible outline on all focusable elements
- Icon-only buttons: aria-label attributes

---

## Responsive Behavior

**Desktop (lg: 1024px+):**
- Full multi-column layouts as described
- Side-by-side enrichment controls and results

**Tablet (md: 768px-1023px):**
- 2-column grids reduce to single column where space is tight
- Provider cards in 2-column grid

**Mobile (< 768px):**
- All grids collapse to single column
- Sticky footer adjusts to mobile viewport
- Tab navigation scrolls horizontally if needed

---

## Animations

**Minimal, Functional Only:**
- Accordion expand/collapse: 200ms ease
- Button state transitions: 150ms
- Loading spinners: Continuous rotation
- Toast notifications: Slide-in from top (300ms)

Avoid decorative animations to maintain professional, efficient feel.