# Deployment Guide for PowerApps Web Resource

## Architecture Overview

This contact enrichment tool is designed as a **web resource** for Microsoft Power Platform (PowerApps/Dynamics 365). The architecture consists of:

1. **Client-Side Web Resource** - React application that embeds in PowerApps Contact forms
2. **API Proxy Backend** - Secure server that makes third-party API calls (prevents key exposure)
3. **Dataverse Storage** - All data stored in Dataverse custom tables (no external database)

## Deployment Steps

### 1. Deploy Backend API Proxy

The Express backend serves as a secure proxy for third-party enrichment APIs and MUST be deployed separately:

**Option A: Azure App Service**
```bash
# Build the backend
npm run build

# Deploy to Azure App Service
# Set environment variables for all API keys:
# - APOLLO_API_KEY
# - BETTERCONTACT_API_KEY
# - FULLENRICH_API_KEY
# - COGNISM_API_KEY
# - CLAY_API_KEY
# - OPENAI_API_KEY
```

**Option B: Azure Functions**
- Convert Express routes to Azure Functions
- Deploy as serverless endpoints
- Configure API keys in Azure Key Vault

### 2. Build Web Resource Files

```bash
# Build the React frontend
npm run build

# Output will be in dist/client
# These files become your web resources
```

### 3. Create Dataverse Custom Entities

Create these custom tables in your Dataverse environment:

**Enrichment History (`new_enrichmenthistory`)**
- `new_contactid` (Lookup to Contact)
- `new_enrichmentmode` (Choice: Force All, Waterfall, Select Source)
- `new_providerlist` (Multiple Lines of Text)
- `new_resultsjson` (Multiple Lines of Text)
- `new_timestamp` (Date and Time)
- `new_status` (Choice: Success, Partial, Failed)

**Enrichment Cache (`new_enrichmentcache`)**
- `new_contactid` (Lookup to Contact)
- `new_provider` (Single Line of Text)
- `new_resultsjson` (Multiple Lines of Text)
- `new_cacheexpiry` (Date and Time)
- `new_timestamp` (Date and Time)

**Audit Log (`new_auditlog`)**
- `new_contactid` (Lookup to Contact)
- `new_operation` (Single Line of Text)
- `new_user` (Lookup to User)
- `new_details` (Multiple Lines of Text)
- `new_timestamp` (Date and Time)

### 4. Upload Web Resources to Dataverse

1. Navigate to Power Apps Maker Portal
2. Go to Solutions → Your Solution → Web Resources
3. Create new web resources:
   - `new_contactenrichment.html` - Main HTML file
   - `new_contactenrichment.js` - JavaScript bundle
   - `new_contactenrichment.css` - Styles

4. Configure the web resource to call your deployed backend:
   - Update API endpoint URLs in the built JavaScript
   - Ensure CORS is configured on the backend for your Dataverse domain

### 5. Embed in Contact Form

1. Open Contact form editor in PowerApps
2. Add new tab called "Enrichments" (or use existing tab)
3. Insert web resource control
4. Select `new_contactenrichment.html`
5. The web resource will automatically:
   - Load contact data from the form context (Xrm.Page.data.entity)
   - Display the current contact information
   - Allow enrichment operations
   - Save history and audit logs to Dataverse
   
No additional parameters are needed - the web resource reads directly from the form context.

### 6. Configure Dataverse Web API Access

The web resource needs to call Dataverse Web API for:
- Reading/writing enrichment history
- Checking cache
- Writing audit logs

Ensure:
- Web resource has proper security roles
- CORS is configured for Dataverse API
- OAuth tokens are obtained through PowerApps context

## Environment Variables (Backend)

Configure these on your deployed backend:

```
APOLLO_API_KEY=your_apollo_key
BETTERCONTACT_API_KEY=your_bettercontact_key
FULLENRICH_API_KEY=your_fullenrich_key
COGNISM_API_KEY=your_cognism_key
CLAY_API_KEY=your_clay_key
OPENAI_API_KEY=your_openai_key
ALLOWED_ORIGINS=https://yourdomain.crm.dynamics.com
```

## Important Notes

- **No External Database**: All data is stored in Dataverse tables only
- **Backend is Stateless**: The Express server only proxies API calls, stores nothing
- **Authentication**: Web resource inherits authentication from PowerApps context
- **API Keys**: Never expose API keys in client-side code - always use backend proxy
- **Caching**: Use Dataverse `new_enrichmentcache` table with TTL logic
- **History**: Store all enrichment attempts in `new_enrichmenthistory` table

## Development vs Production

**Development (Current Replit Setup)**
- Express backend and React frontend run together
- No Dataverse connection required for testing
- Mock data can be used

**Production (PowerApps Deployment)**
- Backend deployed separately (Azure)
- Frontend built and uploaded as web resources
- All persistence through Dataverse Web API
- Embedded in Contact form
