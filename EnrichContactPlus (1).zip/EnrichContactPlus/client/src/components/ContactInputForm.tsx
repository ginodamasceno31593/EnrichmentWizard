import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Contact } from "@shared/schema";
import { UserPlus } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

interface ContactInputFormProps {
  onContactLoad: (contact: Contact) => void;
}

const contactFormSchema = z.object({
  fullname: z.string().min(1, "Full name is required"),
  firstname: z.string().optional(),
  lastname: z.string().optional(),
  emailaddress1: z.string().email("Invalid email").optional().or(z.literal("")),
  mobilephone: z.string().optional(),
  parentcustomerid: z.string().optional(),
  new_linkedinprofile: z.string().url("Invalid URL").optional().or(z.literal("")),
});

type ContactFormValues = z.infer<typeof contactFormSchema>;

export function ContactInputForm({ onContactLoad }: ContactInputFormProps) {
  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      fullname: "Steven Hofer",
      firstname: "Steven",
      lastname: "Hofer",
      emailaddress1: "",
      mobilephone: "",
      parentcustomerid: "Western Forest Products Inc.",
      new_linkedinprofile: "https://www.linkedin.com/in/steven-hofer-22b29762/",
    },
  });

  const onSubmit = (values: ContactFormValues) => {
    const contact: Contact = {
      fullname: values.fullname,
      firstname: values.firstname || undefined,
      lastname: values.lastname || undefined,
      emailaddress1: values.emailaddress1 || undefined,
      mobilephone: values.mobilephone || undefined,
      parentcustomerid: values.parentcustomerid || undefined,
      new_linkedinprofile: values.new_linkedinprofile || undefined,
    };
    onContactLoad(contact);
  };

  return (
    <Card className="mb-2">
      <CardHeader className="p-2">
        <CardTitle className="text-xs flex items-center gap-1">
          <UserPlus className="h-3 w-3" />
          Test Contact Input (Development Mode)
        </CardTitle>
      </CardHeader>
      <CardContent className="p-2 pt-0">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-2">
            <div className="grid grid-cols-2 gap-2">
              <FormField
                control={form.control}
                name="fullname"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs">Full Name</FormLabel>
                    <FormControl>
                      <Input {...field} className="h-8 text-xs" data-testid="input-fullname" />
                    </FormControl>
                    <FormMessage className="text-xs" />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="parentcustomerid"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs">Company</FormLabel>
                    <FormControl>
                      <Input {...field} className="h-8 text-xs" data-testid="input-company" value={field.value || ""} />
                    </FormControl>
                    <FormMessage className="text-xs" />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-2">
              <FormField
                control={form.control}
                name="firstname"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs">First Name</FormLabel>
                    <FormControl>
                      <Input {...field} className="h-8 text-xs" data-testid="input-firstname" value={field.value || ""} />
                    </FormControl>
                    <FormMessage className="text-xs" />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="lastname"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs">Last Name</FormLabel>
                    <FormControl>
                      <Input {...field} className="h-8 text-xs" data-testid="input-lastname" value={field.value || ""} />
                    </FormControl>
                    <FormMessage className="text-xs" />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="new_linkedinprofile"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs">LinkedIn Profile</FormLabel>
                  <FormControl>
                    <Input {...field} className="h-8 text-xs" placeholder="https://www.linkedin.com/in/..." data-testid="input-linkedin" value={field.value || ""} />
                  </FormControl>
                  <FormMessage className="text-xs" />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-2">
              <FormField
                control={form.control}
                name="emailaddress1"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs">Email (Optional)</FormLabel>
                    <FormControl>
                      <Input {...field} className="h-8 text-xs" placeholder="email@example.com" data-testid="input-email" value={field.value || ""} />
                    </FormControl>
                    <FormMessage className="text-xs" />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="mobilephone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs">Mobile (Optional)</FormLabel>
                    <FormControl>
                      <Input {...field} className="h-8 text-xs" placeholder="+1-555-0123" data-testid="input-mobile" value={field.value || ""} />
                    </FormControl>
                    <FormMessage className="text-xs" />
                  </FormItem>
                )}
              />
            </div>

            <Button type="submit" size="sm" className="w-full" data-testid="button-load-contact">
              <UserPlus className="h-3 w-3 mr-1" />
              Load Contact
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
