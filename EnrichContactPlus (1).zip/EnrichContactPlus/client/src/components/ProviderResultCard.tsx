import { EnrichmentResult } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Copy, CheckCircle2, XCircle, Clock, Loader2, AlertCircle, Plus, Check } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { addPhoneNumber } from "@/lib/dataverse";

interface EnrichmentResultWithCache extends EnrichmentResult {
  cached?: boolean;
  cacheTimestamp?: string;
}

interface ProviderResultCardProps {
  result: EnrichmentResultWithCache;
  selectedEmails: string[];
  selectedPhones: string[];
  onToggleEmail: (email: string) => void;
  onTogglePhone: (phone: string) => void;
  contactId: string | null;
  onPhoneAdded?: () => void;
}

const PROVIDER_NAMES: Record<string, string> = {
  apollo: 'Apollo.io',
  bettercontact: 'BetterContact',
  fullenrich: 'FullEnrich',
  cognism: 'Cognism',
  clay: 'Clay.io',
};

const STATUS_CONFIG = {
  pending: { icon: Clock, color: 'bg-muted text-muted-foreground', label: 'Pending' },
  loading: { icon: Loader2, color: 'bg-primary/10 text-primary', label: 'Loading' },
  success: { icon: CheckCircle2, color: 'bg-green-100 text-green-700', label: 'Success' },
  error: { icon: XCircle, color: 'bg-destructive/10 text-destructive', label: 'Error' },
  no_results: { icon: AlertCircle, color: 'bg-yellow-100 text-yellow-700', label: 'No Results' },
};

export function ProviderResultCard({
  result,
  selectedEmails,
  selectedPhones,
  onToggleEmail,
  onTogglePhone,
  contactId,
  onPhoneAdded,
}: ProviderResultCardProps) {
  const { toast } = useToast();
  const statusConfig = STATUS_CONFIG[result.status];
  const StatusIcon = statusConfig.icon;
  const [addedPhones, setAddedPhones] = useState<Set<string>>(new Set());
  const [validatingPhones, setValidatingPhones] = useState<Set<string>>(new Set());

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: `${text} copied to clipboard`,
      });
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Failed to copy",
        description: "Could not copy to clipboard",
      });
    }
  };

  const handleAddPhone = async (phone: string) => {
    if (!contactId) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "No contact ID available",
      });
      return;
    }

    setValidatingPhones(prev => new Set(prev).add(phone));

    try {
      const response = await apiRequest('POST', '/api/validate-phone', {
        phoneNumber: phone,
      });
      const validationResult = await response.json();

      await addPhoneNumber({
        contactId,
        phoneNumber: phone,
        isValidated: validationResult.isValid,
        validationStatus: validationResult.isValid ? 'valid' : 'invalid',
      });

      setAddedPhones(prev => new Set(prev).add(phone));
      
      toast({
        title: "Phone Added",
        description: validationResult.isValid 
          ? `${phone} validated and added successfully`
          : `${phone} added (validation failed)`,
      });

      if (onPhoneAdded) {
        onPhoneAdded();
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Failed to add phone",
        description: error instanceof Error ? error.message : "Unknown error",
      });
    } finally {
      setValidatingPhones(prev => {
        const newSet = new Set(prev);
        newSet.delete(phone);
        return newSet;
      });
    }
  };

  const getCacheAge = () => {
    if (!result.cacheTimestamp) return null;
    
    const cacheDate = new Date(result.cacheTimestamp);
    const now = new Date();
    const diffMs = now.getTime() - cacheDate.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return "just now";
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays}d ago`;
  };

  return (
    <Card className="h-full">
      <CardHeader className="p-0.5">
        <div className="flex items-center justify-between gap-0.5 flex-wrap">
          <CardTitle className="text-[10px] font-semibold">{PROVIDER_NAMES[result.provider]}</CardTitle>
          <div className="flex items-center gap-0.5 flex-wrap">
            {result.cached && (
              <Badge 
                variant="outline" 
                className="flex items-center gap-0.5 px-0.5 py-0 text-[9px] h-4"
                data-testid={`badge-cached-${result.provider}`}
              >
                <Clock className="w-2 h-2" />
                <span>{getCacheAge()}</span>
              </Badge>
            )}
            <Badge className={`${statusConfig.color} flex items-center gap-0.5 px-1 py-0 h-4`}>
              <StatusIcon className={`w-2 h-2 ${result.status === 'loading' ? 'animate-spin' : ''}`} />
              <span className="text-[9px] font-medium">{statusConfig.label}</span>
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0.5 space-y-0.5">
        {result.status === 'error' && result.error && (
          <div className="bg-destructive/10 border border-destructive/20 rounded-sm p-0.5">
            <p className="text-[9px] text-destructive">{result.error}</p>
          </div>
        )}

        {result.status === 'success' && (
          <>
            {/* Mobile Phones Section */}
            {result.mobilePhones.length > 0 && (
              <div>
                <h4 className="text-[9px] font-semibold mb-0.5 text-foreground">
                  Phones ({result.mobilePhones.length})
                </h4>
                <div className="space-y-0.5">
                  {result.mobilePhones.map((phone, idx) => {
                    const isAdded = addedPhones.has(phone);
                    const isValidating = validatingPhones.has(phone);
                    
                    return (
                      <div
                        key={`${phone}-${idx}`}
                        className="flex items-center gap-0.5 p-0.5 rounded-sm hover-elevate border"
                      >
                        <Checkbox
                          id={`phone-${result.provider}-${idx}`}
                          checked={selectedPhones.includes(phone)}
                          onCheckedChange={() => onTogglePhone(phone)}
                          data-testid={`checkbox-phone-${result.provider}-${idx}`}
                          className="w-3 h-3"
                        />
                        <label
                          htmlFor={`phone-${result.provider}-${idx}`}
                          className="flex-1 text-[10px] cursor-pointer"
                        >
                          {phone}
                        </label>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => handleAddPhone(phone)}
                          disabled={isAdded || isValidating}
                          className="h-4 w-4 p-0"
                          data-testid={`button-add-phone-${result.provider}-${idx}`}
                          title={isAdded ? "Added" : "Add"}
                        >
                          {isValidating ? (
                            <Loader2 className="w-2 h-2 animate-spin" />
                          ) : isAdded ? (
                            <Check className="w-2 h-2" />
                          ) : (
                            <Plus className="w-2 h-2" />
                          )}
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => copyToClipboard(phone)}
                          className="h-4 w-4 p-0"
                          data-testid={`button-copy-phone-${result.provider}-${idx}`}
                        >
                          <Copy className="w-2 h-2" />
                        </Button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Emails Section */}
            {result.emails.length > 0 && (
              <div>
                <h4 className="text-[9px] font-semibold mb-0.5 text-foreground">
                  Emails ({result.emails.length})
                </h4>
                <div className="space-y-0.5">
                  {result.emails.map((email, idx) => (
                    <div
                      key={`${email}-${idx}`}
                      className="flex items-center gap-0.5 p-0.5 rounded-sm hover-elevate border"
                    >
                      <Checkbox
                        id={`email-${result.provider}-${idx}`}
                        checked={selectedEmails.includes(email)}
                        onCheckedChange={() => onToggleEmail(email)}
                        data-testid={`checkbox-email-${result.provider}-${idx}`}
                        className="w-3 h-3"
                      />
                      <label
                        htmlFor={`email-${result.provider}-${idx}`}
                        className="flex-1 text-[10px] cursor-pointer break-all"
                      >
                        {email}
                      </label>
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => copyToClipboard(email)}
                        className="h-4 w-4 p-0"
                        data-testid={`button-copy-email-${result.provider}-${idx}`}
                      >
                        <Copy className="w-2 h-2" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {result.mobilePhones.length === 0 && result.emails.length === 0 && (
              <div className="text-center py-1">
                <AlertCircle className="w-4 h-4 mx-auto text-muted-foreground mb-0.5" />
                <p className="text-[9px] text-muted-foreground">No data found</p>
              </div>
            )}

            {result.timestamp && (
              <p className="text-[8px] text-muted-foreground">
                {new Date(result.timestamp).toLocaleTimeString()}
              </p>
            )}
          </>
        )}

        {result.status === 'loading' && (
          <div className="text-center py-1">
            <Loader2 className="w-4 h-4 mx-auto text-primary animate-spin mb-0.5" />
            <p className="text-[9px] text-muted-foreground">Fetching...</p>
          </div>
        )}

        {result.status === 'pending' && (
          <div className="text-center py-1">
            <Clock className="w-4 h-4 mx-auto text-muted-foreground mb-0.5" />
            <p className="text-[9px] text-muted-foreground">Waiting...</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
