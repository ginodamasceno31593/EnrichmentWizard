import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";

type Provider = 'apollo' | 'bettercontact' | 'fullenrich' | 'cognism' | 'clay';

interface ProviderSelectorProps {
  selectedProviders: Provider[];
  onProvidersChange: (providers: Provider[]) => void;
}

const PROVIDERS: { id: Provider; name: string; description: string }[] = [
  { id: 'apollo', name: 'Apollo.io', description: 'B2B contact database' },
  { id: 'bettercontact', name: 'BetterContact', description: 'Email enrichment' },
  { id: 'fullenrich', name: 'FullEnrich', description: 'Complete data enrichment' },
  { id: 'cognism', name: 'Cognism', description: 'International contact data' },
  { id: 'clay', name: 'Clay.io', description: 'Enrichment waterfall' },
];

export function ProviderSelector({ selectedProviders, onProvidersChange }: ProviderSelectorProps) {
  const toggleProvider = (providerId: Provider) => {
    if (selectedProviders.includes(providerId)) {
      onProvidersChange(selectedProviders.filter(p => p !== providerId));
    } else {
      onProvidersChange([...selectedProviders, providerId]);
    }
  };

  return (
    <Card className="mb-6">
      <CardContent className="pt-6">
        <h3 className="text-lg font-semibold mb-4">Select Providers</h3>
        <div className="space-y-3">
          {PROVIDERS.map((provider) => (
            <div key={provider.id} className="flex items-start space-x-3">
              <Checkbox
                id={provider.id}
                checked={selectedProviders.includes(provider.id)}
                onCheckedChange={() => toggleProvider(provider.id)}
                data-testid={`checkbox-provider-${provider.id}`}
              />
              <div className="flex-1">
                <Label
                  htmlFor={provider.id}
                  className="text-base font-medium cursor-pointer"
                >
                  {provider.name}
                </Label>
                <p className="text-sm text-muted-foreground">{provider.description}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
