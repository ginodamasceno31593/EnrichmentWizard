import { Contact } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { ExternalLink } from "lucide-react";

interface ContactDisplayProps {
  contact: Contact;
}

export function ContactDisplay({ contact }: ContactDisplayProps) {
  return (
    <Card>
      <CardContent className="p-0.5">
        <div className="flex flex-wrap items-center gap-0.5 text-[10px]">
          <span className="font-medium" data-testid="text-fullname">
            {contact.fullname}
          </span>
          {contact.emailaddress1 && (
            <>
              <span className="text-muted-foreground">•</span>
              <span data-testid="text-email" className="truncate max-w-[100px]">
                {contact.emailaddress1}
              </span>
            </>
          )}
          {contact.mobilephone && (
            <>
              <span className="text-muted-foreground">•</span>
              <span data-testid="text-mobilephone">
                {contact.mobilephone}
              </span>
            </>
          )}
          {contact.new_linkedinprofile && (
            <>
              <span className="text-muted-foreground">•</span>
              <a
                href={contact.new_linkedinprofile}
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:underline inline-flex items-center gap-0.5"
                data-testid="link-linkedin"
              >
                LinkedIn
                <ExternalLink className="w-2 h-2" />
              </a>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
