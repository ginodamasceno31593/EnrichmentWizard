import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Phone, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface AircallDialModalProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  contactPhone: string;
}

interface CallCount {
  aircallNumber: string;
  label: string;
  count: number;
}

interface CallTrackingResponse {
  contactPhone: string;
  callCounts: CallCount[];
}

export function AircallDialModal({
  isOpen,
  onOpenChange,
  contactPhone,
}: AircallDialModalProps) {
  const { toast } = useToast();

  // Fetch call counts for this contact phone number
  const { data, isLoading, error } = useQuery<CallTrackingResponse>({
    queryKey: ['/api/call-tracking', contactPhone],
    queryFn: async () => {
      const response = await fetch(`/api/call-tracking/${encodeURIComponent(contactPhone)}`);
      if (!response.ok) {
        throw new Error('Failed to fetch call counts');
      }
      return response.json();
    },
    enabled: isOpen && !!contactPhone,
  });

  // Mutation for incrementing call count
  const incrementCallCount = useMutation({
    mutationFn: async (aircallNumber: string) => {
      const response = await apiRequest(
        'POST',
        '/api/call-tracking/increment',
        {
          aircallNumber,
          contactPhone,
        }
      );
      
      if (!response.ok) {
        throw new Error('Failed to increment call count');
      }
      
      return response.json();
    },
    onSuccess: () => {
      // Invalidate the query to refresh the call counts
      queryClient.invalidateQueries({ 
        queryKey: ['/api/call-tracking', contactPhone] 
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to track call",
        variant: "destructive",
      });
    },
  });

  const handleSelectNumber = async (aircallNumber: string) => {
    try {
      // Increment the call count
      await incrementCallCount.mutateAsync(aircallNumber);
      
      // Close the modal
      onOpenChange(false);
      
      // Initiate the call
      const callUrl = `aircall://dial?number=${encodeURIComponent(contactPhone)}&from=${encodeURIComponent(aircallNumber)}`;
      window.location.href = callUrl;
    } catch (error) {
      console.error('Error handling call:', error);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Select Aircall Number</DialogTitle>
          <DialogDescription>
            Choose which Aircall number to use for calling{' '}
            <span className="font-mono">{contactPhone}</span>
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-2 mt-4">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
            </div>
          ) : error ? (
            <div className="text-center py-4">
              <p className="text-sm text-destructive">
                Failed to load Aircall numbers. Please try again.
              </p>
            </div>
          ) : data?.callCounts && data.callCounts.length > 0 ? (
            data.callCounts.map((item) => (
              <Button
                key={item.aircallNumber}
                variant="outline"
                className="w-full justify-start gap-3 p-4 h-auto hover-elevate active-elevate-2"
                onClick={() => handleSelectNumber(item.aircallNumber)}
                disabled={incrementCallCount.isPending}
                data-testid={`button-aircall-${item.aircallNumber}`}
              >
                <Phone className="w-4 h-4 flex-shrink-0" />
                <div className="flex-1 text-left">
                  <div className="font-medium">{item.label}</div>
                  <div className="text-xs text-muted-foreground font-mono">
                    {item.aircallNumber}
                  </div>
                </div>
                {item.count > 0 && (
                  <Badge variant="secondary" className="ml-auto">
                    {item.count} {item.count === 1 ? 'call' : 'calls'}
                  </Badge>
                )}
              </Button>
            ))
          ) : (
            <div className="text-center py-4">
              <p className="text-sm text-muted-foreground">
                No Aircall numbers available
              </p>
            </div>
          )}
        </div>

        {incrementCallCount.isPending && (
          <div className="flex items-center justify-center gap-2 mt-4 text-sm text-muted-foreground">
            <Loader2 className="w-4 h-4 animate-spin" />
            <span>Initiating call...</span>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}