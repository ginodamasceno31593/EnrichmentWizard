import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, UserCheck, Loader2, Copy, ChevronDown, ChevronRight } from "lucide-react";
import { ExecutiveAssistant } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

interface ExecutiveAssistantSearchProps {
  isSearching: boolean;
  assistant: ExecutiveAssistant | null;
  error: string | null;
  onSearch: () => void;
}

export function ExecutiveAssistantSearch({
  isSearching,
  assistant,
  error,
  onSearch,
}: ExecutiveAssistantSearchProps) {
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: `${text} copied to clipboard`,
      });
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Failed to copy",
        description: "Could not copy to clipboard",
      });
    }
  };

  return (
    <Card className="mb-1">
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <CardHeader className="p-0.5">
          <div className="flex items-center justify-between gap-0.5">
            <CollapsibleTrigger className="flex items-center gap-0.5 text-[10px] font-medium hover:underline">
              {isOpen ? (
                <ChevronDown className="w-2 h-2" />
              ) : (
                <ChevronRight className="w-2 h-2" />
              )}
              <UserCheck className="w-2 h-2 text-primary" />
              <span>EA Search</span>
              {assistant && <Badge variant="outline" className="ml-1 px-0.5 py-0 h-4 text-[8px]">Found</Badge>}
            </CollapsibleTrigger>
            <Button
              onClick={onSearch}
              disabled={isSearching}
              data-testid="button-search-ea"
              className="gap-0.5 h-5 px-1 text-[9px]"
              size="sm"
            >
              {isSearching ? (
                <>
                  <Loader2 className="w-2 h-2 animate-spin" />
                  <span>...</span>
                </>
              ) : (
                <>
                  <Search className="w-2 h-2" />
                  <span>Search</span>
                </>
              )}
            </Button>
          </div>
        </CardHeader>
        <CollapsibleContent>
          <CardContent className="p-0.5">
            {error && (
              <div className="bg-destructive/10 border border-destructive/20 rounded-sm p-0.5 mb-0.5">
                <p className="text-[9px] text-destructive">{error}</p>
              </div>
            )}

            {assistant && (
              <div className="space-y-0.5">
                {assistant.confidence && (
                  <div className="flex items-center gap-0.5 mb-0.5">
                    <Badge className="px-0.5 py-0 h-4 text-[8px]">
                      {Math.round(assistant.confidence * 100)}% conf
                    </Badge>
                  </div>
                )}

                <div className="space-y-0.5">
                  <div className="flex items-center gap-0.5">
                    <label className="text-[8px] font-medium text-muted-foreground w-10">
                      Name:
                    </label>
                    <p className="text-[10px] flex-1" data-testid="text-ea-name">
                      {assistant.name}
                    </p>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => copyToClipboard(assistant.name)}
                      className="h-4 w-4 p-0"
                      data-testid="button-copy-ea-name"
                    >
                      <Copy className="w-2 h-2" />
                    </Button>
                  </div>

                  <div className="flex items-center gap-0.5">
                    <label className="text-[8px] font-medium text-muted-foreground w-10">
                      Email:
                    </label>
                    <p className="text-[10px] flex-1 break-all" data-testid="text-ea-email">
                      {assistant.email || '—'}
                    </p>
                    {assistant.email && (
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => copyToClipboard(assistant.email!)}
                        className="h-4 w-4 p-0"
                        data-testid="button-copy-ea-email"
                      >
                        <Copy className="w-2 h-2" />
                      </Button>
                    )}
                  </div>

                  <div className="flex items-center gap-0.5">
                    <label className="text-[8px] font-medium text-muted-foreground w-10">
                      Phone:
                    </label>
                    <p className="text-[10px] flex-1" data-testid="text-ea-phone">
                      {assistant.phone || '—'}
                    </p>
                    {assistant.phone && (
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => copyToClipboard(assistant.phone!)}
                        className="h-4 w-4 p-0"
                        data-testid="button-copy-ea-phone"
                      >
                        <Copy className="w-2 h-2" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            )}

            {!assistant && !error && !isSearching && (
              <div className="text-center py-1">
                <Search className="w-4 h-4 mx-auto text-muted-foreground mb-0.5" />
                <p className="text-[9px] text-muted-foreground">
                  Click Search to find EA
                </p>
              </div>
            )}
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}
