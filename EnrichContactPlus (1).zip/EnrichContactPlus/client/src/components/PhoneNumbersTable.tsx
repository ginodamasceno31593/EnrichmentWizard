import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, XCircle, Phone, Loader2 } from "lucide-react";
import { getPhoneNumbersForContact, getCurrentContactId } from "@/lib/dataverse";
import { AircallDialModal } from "./AircallDialModal";

interface PhoneNumbersTableProps {
  contactId: string | null;
  refreshTrigger?: number;
}

export function PhoneNumbersTable({ contactId, refreshTrigger }: PhoneNumbersTableProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedPhoneNumber, setSelectedPhoneNumber] = useState<string>("");

  const { data: phoneNumbers, isLoading } = useQuery({
    queryKey: ['/api/phone-numbers', contactId, refreshTrigger],
    queryFn: async () => {
      if (!contactId) return [];
      return await getPhoneNumbersForContact(contactId);
    },
    enabled: !!contactId,
  });

  const handleDial = (phoneNumber: string) => {
    setSelectedPhoneNumber(phoneNumber);
    setIsModalOpen(true);
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader className="p-0.5">
          <CardTitle className="text-[10px]">Phone Numbers</CardTitle>
        </CardHeader>
        <CardContent className="p-0.5">
          <div className="flex items-center justify-center py-1">
            <Loader2 className="w-3 h-3 animate-spin text-muted-foreground" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!phoneNumbers || phoneNumbers.length === 0) {
    return (
      <Card>
        <CardHeader className="p-0.5">
          <CardTitle className="text-[10px]">Phone Numbers</CardTitle>
        </CardHeader>
        <CardContent className="p-0.5">
          <p className="text-[9px] text-muted-foreground">
            No phone numbers added yet.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader className="p-0.5">
          <CardTitle className="text-[10px]">
            Phone Numbers ({phoneNumbers.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0.5">
          <div className="space-y-0.5">
            {phoneNumbers.map((phone) => (
              <div
                key={phone.cr533_phonenumbersid}
                className="flex items-center gap-0.5 p-0.5 rounded-sm border hover-elevate"
                data-testid={`phone-row-${phone.cr533_phonenumber}`}
              >
                {phone.cr533_isvalidated && phone.cr533_validationstatus === 'valid' ? (
                  <CheckCircle 
                    className="w-2 h-2 text-green-600 flex-shrink-0" 
                    data-testid={`icon-valid-${phone.cr533_phonenumber}`}
                  />
                ) : phone.cr533_validationstatus === 'invalid' ? (
                  <XCircle 
                    className="w-2 h-2 text-destructive flex-shrink-0" 
                    data-testid={`icon-invalid-${phone.cr533_phonenumber}`}
                  />
                ) : (
                  <Loader2 
                    className="w-2 h-2 text-muted-foreground flex-shrink-0 animate-spin" 
                    data-testid={`icon-pending-${phone.cr533_phonenumber}`}
                  />
                )}
                
                <span className="flex-1 text-[10px] font-mono" data-testid={`text-phone-${phone.cr533_phonenumber}`}>
                  {phone.cr533_phonenumber}
                </span>
                
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => handleDial(phone.cr533_phonenumber)}
                  className="h-5 w-5 p-0"
                  data-testid={`button-dial-${phone.cr533_phonenumber}`}
                  title="Dial"
                >
                  <Phone className="w-2 h-2" />
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      <AircallDialModal
        isOpen={isModalOpen}
        onOpenChange={setIsModalOpen}
        contactPhone={selectedPhoneNumber}
      />
    </>
  );
}
