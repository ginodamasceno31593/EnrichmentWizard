import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getEnrichmentHistory, isPowerAppsContext, type EnrichmentHistory } from "@/lib/dataverse";
import { Clock, CheckCircle, AlertCircle, XCircle } from "lucide-react";
import { format } from "date-fns";

interface EnrichmentHistoryProps {
  contactId: string | null;
  refreshTrigger?: number;
}

export function EnrichmentHistoryComponent({ contactId, refreshTrigger }: EnrichmentHistoryProps) {
  const [history, setHistory] = useState<EnrichmentHistory[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!contactId) {
      setHistory([]);
      return;
    }

    const fetchHistory = async () => {
      setIsLoading(true);
      try {
        const data = await getEnrichmentHistory(contactId, 10);
        setHistory(data);
      } catch (error) {
        console.error("Failed to fetch enrichment history:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchHistory();
  }, [contactId, refreshTrigger]);

  if (!contactId) {
    return null;
  }

  const getStatusBadge = (status?: string) => {
    switch (status) {
      case 'success':
        return (
          <Badge variant="default" className="gap-0.5 px-0.5 py-0 h-4" data-testid={`badge-status-success`}>
            <CheckCircle className="w-2 h-2" />
            <span className="text-[8px]">OK</span>
          </Badge>
        );
      case 'partial':
        return (
          <Badge variant="secondary" className="gap-0.5 px-0.5 py-0 h-4" data-testid={`badge-status-partial`}>
            <AlertCircle className="w-2 h-2" />
            <span className="text-[8px]">Part</span>
          </Badge>
        );
      case 'failed':
        return (
          <Badge variant="destructive" className="gap-0.5 px-0.5 py-0 h-4" data-testid={`badge-status-failed`}>
            <XCircle className="w-2 h-2" />
            <span className="text-[8px]">Fail</span>
          </Badge>
        );
      default:
        return (
          <Badge variant="outline" className="px-0.5 py-0 h-4" data-testid={`badge-status-unknown`}>
            <span className="text-[8px]">?</span>
          </Badge>
        );
    }
  };

  const formatMode = (mode?: string) => {
    if (!mode) return 'Unknown';
    switch (mode) {
      case 'force_all':
        return 'Force Run All';
      case 'waterfall':
        return 'Waterfall';
      case 'select_source':
        return 'Select Source';
      default:
        return mode;
    }
  };

  const getResultSummary = (resultsJson?: string) => {
    if (!resultsJson) return { emails: 0, phones: 0, providers: 0 };
    
    try {
      const results = JSON.parse(resultsJson);
      if (!Array.isArray(results)) return { emails: 0, phones: 0, providers: 0 };
      
      const successResults = results.filter((r: any) => r.status === 'success');
      const emails = new Set<string>();
      const phones = new Set<string>();
      
      successResults.forEach((r: any) => {
        if (r.emails && Array.isArray(r.emails)) {
          r.emails.forEach((e: string) => emails.add(e));
        }
        if (r.mobilePhones && Array.isArray(r.mobilePhones)) {
          r.mobilePhones.forEach((p: string) => phones.add(p));
        }
      });
      
      return {
        emails: emails.size,
        phones: phones.size,
        providers: successResults.length,
      };
    } catch (error) {
      console.error('Failed to parse results JSON:', error);
      return { emails: 0, phones: 0, providers: 0 };
    }
  };

  if (isLoading) {
    return (
      <Card data-testid="card-enrichment-history-loading">
        <CardHeader className="p-0.5">
          <CardTitle className="flex items-center gap-0.5 text-[10px]">
            <Clock className="w-2 h-2" />
            Enrichment History
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0.5">
          <div className="flex items-center justify-center py-1">
            <div className="text-[9px] text-muted-foreground">Loading...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!isPowerAppsContext() && history.length === 0) {
    return (
      <Card data-testid="card-enrichment-history-dev-mode">
        <CardHeader className="p-0.5">
          <CardTitle className="flex items-center gap-0.5 text-[10px]">
            <Clock className="w-2 h-2" />
            Enrichment History
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0.5">
          <div className="text-[9px] text-muted-foreground">
            <p className="mb-0.5">History will be available in PowerApps.</p>
            <p className="text-[8px]">Dev mode: History logged to console.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (history.length === 0) {
    return (
      <Card data-testid="card-enrichment-history-empty">
        <CardHeader className="p-0.5">
          <CardTitle className="flex items-center gap-0.5 text-[10px]">
            <Clock className="w-2 h-2" />
            Enrichment History
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0.5">
          <div className="text-[9px] text-muted-foreground text-center py-0.5">
            No enrichment history found.
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="card-enrichment-history">
      <CardHeader className="p-0.5">
        <CardTitle className="flex items-center gap-0.5 text-[10px]">
          <Clock className="w-2 h-2" />
          Enrichment History
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0.5">
        <div className="space-y-0.5">
          {history.map((item, index) => {
            const summary = getResultSummary(item.new_resultsjson);
            const providers = item.new_providerlist 
              ? JSON.parse(item.new_providerlist).join(', ') 
              : 'N/A';
            
            return (
              <div
                key={item.new_enrichmenthistoryid || index}
                className="border rounded-sm p-0.5 hover-elevate"
                data-testid={`history-item-${index}`}
              >
                <div className="flex items-start justify-between gap-0.5 mb-0.5">
                  <div className="flex-1">
                    <div className="flex items-center gap-0.5 mb-0.5">
                      <span className="text-[9px] font-medium" data-testid={`text-mode-${index}`}>
                        {formatMode(item.new_enrichmentmode)}
                      </span>
                      {getStatusBadge(item.new_status)}
                    </div>
                    <div className="text-[8px] text-muted-foreground" data-testid={`text-timestamp-${index}`}>
                      {item.new_timestamp 
                        ? format(new Date(item.new_timestamp), 'MMM d, h:mm a')
                        : 'Unknown'}
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-0.5 text-[9px]">
                  <div>
                    <div className="text-[8px] text-muted-foreground mb-0.5">Providers</div>
                    <div className="font-medium" data-testid={`text-providers-${index}`}>
                      {summary.providers > 0 ? summary.providers : 'None'}
                    </div>
                  </div>
                  <div>
                    <div className="text-[8px] text-muted-foreground mb-0.5">Results</div>
                    <div className="font-medium" data-testid={`text-results-${index}`}>
                      {summary.emails}E, {summary.phones}P
                    </div>
                  </div>
                </div>
                
                {item.new_providerlist && (
                  <div className="mt-0.5 pt-0.5 border-t">
                    <div className="text-[8px]" data-testid={`text-provider-list-${index}`}>
                      {providers}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
