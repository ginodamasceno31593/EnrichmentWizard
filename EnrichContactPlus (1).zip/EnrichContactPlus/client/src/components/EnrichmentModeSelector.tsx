import { EnrichmentMode } from "@shared/schema";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Zap, Layers, CheckSquare } from "lucide-react";

interface EnrichmentModeSelectorProps {
  mode: EnrichmentMode;
  onModeChange: (mode: EnrichmentMode) => void;
}

export function EnrichmentModeSelector({ mode, onModeChange }: EnrichmentModeSelectorProps) {
  return (
    <div className="mb-6">
      <h3 className="text-lg font-semibold mb-3">Enrichment Mode</h3>
      <Tabs value={mode} onValueChange={(value) => onModeChange(value as EnrichmentMode)}>
        <TabsList className="grid w-full grid-cols-3 h-auto">
          <TabsTrigger 
            value="force_all" 
            className="flex flex-col items-center gap-1 py-3"
            data-testid="button-mode-forceall"
          >
            <Zap className="w-4 h-4" />
            <span className="text-sm font-medium">Force Run All</span>
            <span className="text-xs text-muted-foreground">Parallel requests</span>
          </TabsTrigger>
          <TabsTrigger 
            value="waterfall" 
            className="flex flex-col items-center gap-1 py-3"
            data-testid="button-mode-waterfall"
          >
            <Layers className="w-4 h-4" />
            <span className="text-sm font-medium">Waterfall</span>
            <span className="text-xs text-muted-foreground">Stop on success</span>
          </TabsTrigger>
          <TabsTrigger 
            value="select_source" 
            className="flex flex-col items-center gap-1 py-3"
            data-testid="button-mode-selectsource"
          >
            <CheckSquare className="w-4 h-4" />
            <span className="text-sm font-medium">Select Source</span>
            <span className="text-xs text-muted-foreground">Choose providers</span>
          </TabsTrigger>
        </TabsList>
      </Tabs>
    </div>
  );
}
