import { useState } from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Settings, Eye, EyeOff, CheckCircle2, XCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ApiConfig {
  apolloKey: string;
  bettercontactKey: string;
  fullenrichKey: string;
  cognismKey: string;
  clayKey: string;
  openaiKey: string;
}

export function ApiConfigPanel() {
  const { toast } = useToast();
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({});
  const [config, setConfig] = useState<ApiConfig>({
    apolloKey: "",
    bettercontactKey: "",
    fullenrichKey: "",
    cognismKey: "",
    clayKey: "",
    openaiKey: "",
  });

  const toggleKeyVisibility = (key: string) => {
    setShowKeys(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleSave = () => {
    toast({
      title: "Configuration Saved",
      description: "API keys have been saved. Note: In production, these would be securely stored in environment variables.",
    });
  };

  const providers = [
    { id: 'apolloKey', name: 'Apollo.io', key: config.apolloKey },
    { id: 'bettercontactKey', name: 'BetterContact', key: config.bettercontactKey },
    { id: 'fullenrichKey', name: 'FullEnrich', key: config.fullenrichKey },
    { id: 'cognismKey', name: 'Cognism', key: config.cognismKey },
    { id: 'clayKey', name: 'Clay.io', key: config.clayKey },
    { id: 'openaiKey', name: 'OpenAI', key: config.openaiKey },
  ];

  return (
    <Card className="mb-6">
      <Accordion type="single" collapsible>
        <AccordionItem value="config" className="border-none">
          <CardHeader className="pb-0">
            <AccordionTrigger className="hover:no-underline py-4">
              <div className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-primary" />
                <CardTitle className="text-xl">API Configuration</CardTitle>
                <Badge variant="outline" className="ml-2">
                  {providers.filter(p => p.key).length}/{providers.length} configured
                </Badge>
              </div>
            </AccordionTrigger>
          </CardHeader>
          <AccordionContent>
            <CardContent className="pt-4">
              <div className="space-y-6">
                <div className="bg-muted/50 border border-border rounded-md p-4">
                  <p className="text-sm text-muted-foreground">
                    <strong>Note:</strong> In production, API keys are managed through environment variables on the server. 
                    This panel is for demonstration purposes. The application will use the pre-configured keys from your environment.
                  </p>
                </div>

                {providers.map((provider) => (
                  <div key={provider.id} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor={provider.id} className="text-base font-medium">
                        {provider.name}
                      </Label>
                      {provider.key && (
                        <Badge className="bg-green-100 text-green-700 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          Configured
                        </Badge>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <Input
                          id={provider.id}
                          type={showKeys[provider.id] ? "text" : "password"}
                          value={provider.key}
                          onChange={(e) =>
                            setConfig({ ...config, [provider.id]: e.target.value })
                          }
                          placeholder="Enter API key..."
                          data-testid={`input-apikey-${provider.id}`}
                        />
                      </div>
                      <Button
                        type="button"
                        size="icon"
                        variant="outline"
                        onClick={() => toggleKeyVisibility(provider.id)}
                        data-testid={`button-toggle-${provider.id}`}
                      >
                        {showKeys[provider.id] ? (
                          <EyeOff className="w-4 h-4" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                ))}

                <Button
                  onClick={handleSave}
                  className="w-full"
                  data-testid="button-save-config"
                >
                  Save Configuration
                </Button>
              </div>
            </CardContent>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </Card>
  );
}
