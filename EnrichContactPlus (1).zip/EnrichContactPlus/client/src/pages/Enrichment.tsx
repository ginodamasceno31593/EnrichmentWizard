import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ContactDisplay } from "@/components/ContactDisplay";
import { ContactInputForm } from "@/components/ContactInputForm";
import { ApiConfigPanel } from "@/components/ApiConfigPanel";
import { EnrichmentModeSelector } from "@/components/EnrichmentModeSelector";
import { ProviderSelector } from "@/components/ProviderSelector";
import { ProviderResultCard } from "@/components/ProviderResultCard";
import { ExecutiveAssistantSearch } from "@/components/ExecutiveAssistantSearch";
import { EnrichmentHistoryComponent } from "@/components/EnrichmentHistory";
import { PhoneNumbersTable } from "@/components/PhoneNumbersTable";
import { Sparkles, Download, RefreshCw, Trash2, ChevronDown, ChevronRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type {
  Contact,
  EnrichmentMode,
  EnrichmentResult,
  ExecutiveAssistant,
} from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  saveEnrichmentHistory, 
  createAuditLog, 
  getCurrentContactId, 
  getContactDataFromForm, 
  isPowerAppsContext,
  getCachedEnrichment,
  saveToCache,
  clearContactCache,
} from "@/lib/dataverse";

type Provider = 'apollo' | 'bettercontact' | 'fullenrich' | 'cognism' | 'clay';

interface EnrichmentResultWithCache extends EnrichmentResult {
  cached?: boolean;
  cacheTimestamp?: string;
}

export default function Enrichment() {
  const { toast } = useToast();
  const [contact, setContact] = useState<Contact | null>(null);
  const [contactId, setContactId] = useState<string | null>(null);
  const [historyRefreshTrigger, setHistoryRefreshTrigger] = useState(0);
  const [mode, setMode] = useState<EnrichmentMode>('force_all');
  const [selectedProviders, setSelectedProviders] = useState<Provider[]>([
    'apollo',
    'bettercontact',
    'fullenrich',
    'cognism',
    'clay',
  ]);
  const [enrichmentResults, setEnrichmentResults] = useState<EnrichmentResultWithCache[]>([]);
  const [selectedEmails, setSelectedEmails] = useState<string[]>([]);
  const [selectedPhones, setSelectedPhones] = useState<string[]>([]);
  const [eaAssistant, setEaAssistant] = useState<ExecutiveAssistant | null>(null);
  const [eaError, setEaError] = useState<string | null>(null);
  const [forceRefresh, setForceRefresh] = useState(false);
  const [phoneTableRefresh, setPhoneTableRefresh] = useState(0);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [providerSelectorOpen, setProviderSelectorOpen] = useState(false);
  const [contactOpen, setContactOpen] = useState(false);
  const [phoneTableOpen, setPhoneTableOpen] = useState(false);
  const [resultsOpen, setResultsOpen] = useState(false);
  const [eaSearchOpen, setEaSearchOpen] = useState(false);

  // Auto-load contact data from PowerApps form on mount
  useEffect(() => {
    loadContactFromForm();
  }, []);

  const loadContactFromForm = () => {
    const contactData = getContactDataFromForm();
    if (contactData) {
      setContact(contactData);
      const currentContactId = getCurrentContactId() || `dev-${Date.now()}`;
      setContactId(currentContactId);
    }
  };

  const enrichMutation = useMutation({
    mutationFn: async () => {
      if (!contact) {
        throw new Error("No contact set");
      }
      
      const currentContactId = getCurrentContactId() || contactId || 'dev-contact-id';
      const allProviders: Provider[] = mode === 'select_source' 
        ? selectedProviders 
        : ['apollo', 'bettercontact', 'fullenrich', 'cognism', 'clay'];
      
      const results: EnrichmentResultWithCache[] = [];
      const providersNeedingFetch: Provider[] = [];
      
      // Check cache for each provider (unless Force Refresh is enabled)
      for (const provider of allProviders) {
        if (!forceRefresh) {
          try {
            const cached = await getCachedEnrichment(currentContactId, provider);
            if (cached) {
              // Use cached data
              results.push({
                provider,
                status: 'success',
                emails: cached.emails || [],
                mobilePhones: cached.mobilePhones || [],
                timestamp: cached.timestamp,
                cached: true,
                cacheTimestamp: cached.timestamp,
              });
              continue;
            }
          } catch (error) {
            console.error(`Cache check failed for ${provider}:`, error);
          }
        }
        
        // No cache or Force Refresh - need to fetch from API
        providersNeedingFetch.push(provider);
      }
      
      // Fetch from API for providers not in cache
      if (providersNeedingFetch.length > 0) {
        const response = await apiRequest('POST', '/api/enrich', {
          contact,
          mode,
          providers: providersNeedingFetch,
        });
        const apiData: { results: EnrichmentResult[] } = await response.json();
        
        // Save successful results to cache and add to results
        for (const result of apiData.results) {
          if (result.status === 'success') {
            try {
              await saveToCache({
                contactId: currentContactId,
                provider: result.provider,
                results: {
                  emails: result.emails,
                  mobilePhones: result.mobilePhones,
                  timestamp: result.timestamp || new Date().toISOString(),
                },
                ttlMinutes: 60,
              });
            } catch (error) {
              console.error(`Failed to save cache for ${result.provider}:`, error);
            }
          }
          
          results.push({
            ...result,
            cached: false,
          });
        }
      }
      
      return { results };
    },
    onSuccess: async (data: { results: EnrichmentResultWithCache[] }) => {
      setEnrichmentResults(data.results);
      
      // Determine enrichment status
      const successCount = data.results.filter(r => r.status === 'success').length;
      const errorCount = data.results.filter(r => r.status === 'error').length;
      const cachedCount = data.results.filter(r => r.cached).length;
      let status: 'success' | 'partial' | 'failed';
      
      if (successCount > 0 && errorCount === 0) {
        status = 'success';
      } else if (successCount > 0 && errorCount > 0) {
        status = 'partial';
      } else {
        status = 'failed';
      }
      
      // Get contact ID (from PowerApps context or use a generated ID)
      const currentContactId = getCurrentContactId() || contactId || 'dev-contact-id';
      
      // Get provider list
      const usedProviders = mode === 'select_source' 
        ? selectedProviders 
        : ['apollo', 'bettercontact', 'fullenrich', 'cognism', 'clay'];
      
      // Save enrichment history to Dataverse
      try {
        await saveEnrichmentHistory({
          contactId: currentContactId,
          mode,
          providers: usedProviders,
          results: data.results,
          status,
        });
        
        // Create audit log entry
        await createAuditLog({
          contactId: currentContactId,
          operation: 'enrichment',
          details: {
            mode,
            providers: usedProviders,
            status,
            successCount,
            errorCount,
            cachedCount,
            timestamp: new Date().toISOString(),
          },
        });
        
        // Trigger history refresh
        setHistoryRefreshTrigger(prev => prev + 1);
      } catch (error) {
        console.error('Dataverse save error:', error);
        
        // Show warning toast but don't fail the whole operation
        toast({
          variant: "destructive",
          title: "Warning: History Not Saved",
          description: "Enrichment completed successfully, but history could not be saved to Dataverse. Check console for details.",
        });
      }
      
      toast({
        title: "Enrichment Complete",
        description: `Received ${successCount} result(s) (${cachedCount} from cache)`,
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Enrichment Failed",
        description: error.message,
      });
    },
  });

  const eaMutation = useMutation({
    mutationFn: async () => {
      if (!contact) {
        throw new Error("No contact set");
      }
      const response = await apiRequest('POST', '/api/search-ea', {
        contact,
      });
      return response.json();
    },
    onSuccess: (data: { assistant?: ExecutiveAssistant; error?: string }) => {
      if (data.assistant) {
        setEaAssistant(data.assistant);
        setEaError(null);
        toast({
          title: "Executive Assistant Found",
          description: `Found: ${data.assistant.name}`,
        });
      } else {
        setEaError(data.error || "No assistant found");
        toast({
          variant: "destructive",
          title: "No Results",
          description: data.error || "Could not find an executive assistant",
        });
      }
    },
    onError: (error: Error) => {
      setEaError(error.message);
      toast({
        variant: "destructive",
        title: "Search Failed",
        description: error.message,
      });
    },
  });

  const handleEnrich = () => {
    if (!contact) {
      toast({
        variant: "destructive",
        title: "No Contact Set",
        description: "Please set contact information first",
      });
      return;
    }
    if (mode === 'select_source' && selectedProviders.length === 0) {
      toast({
        variant: "destructive",
        title: "No Providers Selected",
        description: "Please select at least one provider",
      });
      return;
    }
    enrichMutation.mutate();
  };

  const toggleEmail = (email: string) => {
    setSelectedEmails(prev =>
      prev.includes(email) ? prev.filter(e => e !== email) : [...prev, email]
    );
  };

  const togglePhone = (phone: string) => {
    setSelectedPhones(prev =>
      prev.includes(phone) ? prev.filter(p => p !== phone) : [...prev, phone]
    );
  };

  const handleApplyChanges = () => {
    if (!contact) return;
    
    // Update contact with selected enriched data
    const updatedContact: Contact = {
      ...contact,
      emailaddress1: selectedEmails[0] || contact.emailaddress1,
      mobilephone: selectedPhones[0] || contact.mobilephone,
      // In production, this would write to PowerApps via Dataverse Web API
    };
    
    setContact(updatedContact);
    
    toast({
      title: "Data Applied",
      description: `Updated contact with ${selectedEmails.length > 0 ? 'email' : ''}${selectedEmails.length > 0 && selectedPhones.length > 0 ? ' and ' : ''}${selectedPhones.length > 0 ? 'mobile phone' : ''}. Ready for PowerApps Dataverse sync.`,
    });
    
    // Clear selections after applying
    setSelectedEmails([]);
    setSelectedPhones([]);
  };

  const handleClearCache = async () => {
    if (!contactId) {
      toast({
        variant: "destructive",
        title: "No Contact ID",
        description: "Cannot clear cache without a contact ID",
      });
      return;
    }

    try {
      await clearContactCache(contactId);
      setEnrichmentResults([]);
      toast({
        title: "Cache Cleared",
        description: "All cached enrichment data has been cleared for this contact",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Failed to Clear Cache",
        description: error instanceof Error ? error.message : "Unknown error",
      });
    }
  };

  return (
    <div className="bg-background w-[300px] h-[400px] overflow-y-auto overflow-x-hidden compact-scroll">
      <div className="p-0.5">
        {/* Development Mode UI Elements - Only show when NOT in PowerApps */}
        {!isPowerAppsContext() && (
          <>
            {/* Development Mode Indicator */}
            <Badge variant="outline" className="text-[9px] mb-0.5" data-testid="badge-dev-mode">
              Dev Mode
            </Badge>

            {/* Contact Input Form - Development Mode Only */}
            <ContactInputForm 
              onContactLoad={(loadedContact) => {
                setContact(loadedContact);
                setContactId(`dev-${Date.now()}`);
                toast({
                  title: "Contact Loaded",
                  description: `Loaded ${loadedContact.fullname} for testing`,
                });
              }} 
            />

            {/* API Configuration - Development Mode Only */}
            <Collapsible className="mb-0.5">
              <CollapsibleTrigger asChild>
                <Button variant="ghost" size="sm" className="text-[10px] gap-0.5 p-0.5 h-5 w-full justify-start" data-testid="button-toggle-api-config">
                  <ChevronDown className="w-2 h-2 transition-transform" />
                  API Config
                </Button>
              </CollapsibleTrigger>
              <CollapsibleContent>
                <ApiConfigPanel />
              </CollapsibleContent>
            </Collapsible>
          </>
        )}

        {/* Current Contact Information - Collapsible */}
        {contact && (
          <Collapsible open={contactOpen} onOpenChange={setContactOpen} className="mb-0.5">
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="sm" className="text-[10px] gap-0.5 p-0.5 h-5 w-full justify-start" data-testid="button-toggle-contact">
                {contactOpen ? <ChevronDown className="w-2 h-2" /> : <ChevronRight className="w-2 h-2" />}
                Contact: {contact.fullname}
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <ContactDisplay contact={contact} />
            </CollapsibleContent>
          </Collapsible>
        )}

        {/* Phone Numbers Table - Collapsible */}
        {contact && (
          <Collapsible open={phoneTableOpen} onOpenChange={setPhoneTableOpen} className="mb-0.5">
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="sm" className="text-[10px] gap-0.5 p-0.5 h-5 w-full justify-start" data-testid="button-toggle-phones">
                {phoneTableOpen ? <ChevronDown className="w-2 h-2" /> : <ChevronRight className="w-2 h-2" />}
                Phone Numbers
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <PhoneNumbersTable contactId={contactId} refreshTrigger={phoneTableRefresh} />
            </CollapsibleContent>
          </Collapsible>
        )}

        {/* Enrichment Controls - ultra-compact */}
        {contact && (
          <div className="mb-0.5 space-y-0.5">
            <div className="flex items-center gap-0.5 flex-wrap">
              <EnrichmentModeSelector mode={mode} onModeChange={setMode} />
              <div className="flex items-center gap-0.5">
                <Checkbox
                  id="force-refresh"
                  checked={forceRefresh}
                  onCheckedChange={(checked) => setForceRefresh(checked === true)}
                  data-testid="checkbox-force-refresh"
                  className="w-3 h-3"
                />
                <label htmlFor="force-refresh" className="text-[10px] cursor-pointer">
                  Refresh
                </label>
              </div>
              <Button
                onClick={handleEnrich}
                disabled={enrichMutation.isPending}
                size="sm"
                className="gap-0.5 px-1 py-0.5 h-5 text-[10px]"
                data-testid="button-run-enrichment"
              >
                <Sparkles className="w-2 h-2" />
                {enrichMutation.isPending ? 'Running...' : 'Enrich'}
              </Button>
            </div>

            {/* Collapsible Provider Selector */}
            {mode === 'select_source' && (
              <Collapsible open={providerSelectorOpen} onOpenChange={setProviderSelectorOpen}>
                <CollapsibleTrigger asChild>
                  <Button variant="ghost" size="sm" className="text-[10px] gap-0.5 p-0.5 h-5 w-full justify-start" data-testid="button-toggle-providers">
                    {providerSelectorOpen ? <ChevronDown className="w-2 h-2" /> : <ChevronRight className="w-2 h-2" />}
                    Providers ({selectedProviders.length})
                  </Button>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <ProviderSelector
                    selectedProviders={selectedProviders}
                    onProvidersChange={setSelectedProviders}
                  />
                </CollapsibleContent>
              </Collapsible>
            )}
          </div>
        )}

        {/* Enrichment Results - Collapsible */}
        {enrichmentResults.length > 0 && (
          <Collapsible open={resultsOpen} onOpenChange={setResultsOpen} className="mb-0.5">
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="sm" className="text-[10px] gap-0.5 p-0.5 h-5 w-full justify-start" data-testid="button-toggle-results">
                {resultsOpen ? <ChevronDown className="w-2 h-2" /> : <ChevronRight className="w-2 h-2" />}
                Results ({enrichmentResults.length})
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <div className="space-y-0.5">
                {enrichmentResults.map((result) => (
                  <ProviderResultCard
                    key={result.provider}
                    result={result}
                    selectedEmails={selectedEmails}
                    selectedPhones={selectedPhones}
                    onToggleEmail={toggleEmail}
                    onTogglePhone={togglePhone}
                    contactId={contactId}
                    onPhoneAdded={() => setPhoneTableRefresh(prev => prev + 1)}
                  />
                ))}
              </div>
            </CollapsibleContent>
          </Collapsible>
        )}

        {/* Collapsible Enrichment History */}
        {contact && (
          <Collapsible open={historyOpen} onOpenChange={setHistoryOpen} className="mb-0.5">
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="sm" className="text-[10px] gap-0.5 p-0.5 h-5 w-full justify-start" data-testid="button-toggle-history">
                {historyOpen ? <ChevronDown className="w-2 h-2" /> : <ChevronRight className="w-2 h-2" />}
                History
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <EnrichmentHistoryComponent 
                contactId={contactId} 
                refreshTrigger={historyRefreshTrigger}
              />
            </CollapsibleContent>
          </Collapsible>
        )}

        {/* Executive Assistant Search - Collapsible */}
        {contact && (
          <Collapsible open={eaSearchOpen} onOpenChange={setEaSearchOpen} className="mb-0.5">
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="sm" className="text-[10px] gap-0.5 p-0.5 h-5 w-full justify-start" data-testid="button-toggle-ea">
                {eaSearchOpen ? <ChevronDown className="w-2 h-2" /> : <ChevronRight className="w-2 h-2" />}
                Executive Assistant Search
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <ExecutiveAssistantSearch
                isSearching={eaMutation.isPending}
                assistant={eaAssistant}
                error={eaError}
                onSearch={() => eaMutation.mutate()}
              />
            </CollapsibleContent>
          </Collapsible>
        )}

        {/* Apply Changes - Inline */}
        {(selectedEmails.length > 0 || selectedPhones.length > 0) && (
          <div className="mt-0.5 bg-card border rounded-sm p-0.5">
            <div className="flex items-center justify-between gap-0.5">
              <span className="text-[10px]">
                {selectedEmails.length + selectedPhones.length} selected
              </span>
              <div className="flex gap-0.5">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setSelectedEmails([]);
                    setSelectedPhones([]);
                  }}
                  className="px-1 py-0.5 h-5 text-[10px]"
                  data-testid="button-clear-selection"
                >
                  Clear
                </Button>
                <Button
                  size="sm"
                  onClick={handleApplyChanges}
                  className="gap-0.5 px-1 py-0.5 h-5 text-[10px]"
                  data-testid="button-apply-changes"
                >
                  <Download className="w-2 h-2" />
                  Apply
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
