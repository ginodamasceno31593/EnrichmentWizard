/**
 * Client-side Dataverse Web API helpers
 * 
 * These functions run in the browser within the PowerApps web resource context
 * and use the Xrm.WebApi for authenticated Dataverse calls.
 */

import type { Contact } from "@shared/schema";

/**
 * Normalize GUID by removing braces
 * PowerApps provides GUIDs with braces, but Dataverse OData requires them without
 */
function normalizeGuid(id: string): string {
  return id.replace(/[{}]/g, '');
}

declare global {
  interface Window {
    Xrm?: {
      WebApi: {
        createRecord(entityName: string, data: any): Promise<{ id: string }>;
        updateRecord(entityName: string, id: string, data: any): Promise<void>;
        deleteRecord(entityName: string, id: string): Promise<void>;
        retrieveMultipleRecords(
          entityName: string,
          options?: string,
          maxPageSize?: number
        ): Promise<{ entities: any[]; fetchXmlPagingCookie?: string }>;
        retrieveRecord(
          entityName: string,
          id: string,
          options?: string
        ): Promise<any>;
      };
      Page: {
        data: {
          entity: {
            getId(): string;
            getEntityName(): string;
            attributes: {
              get(attributeName: string): {
                getValue(): any;
              } | null;
            };
          };
        };
      };
    };
  }
}

export interface EnrichmentHistory {
  new_enrichmenthistoryid?: string;
  new_contactid?: string;
  new_enrichmentmode?: string;
  new_providerlist?: string;
  new_resultsjson?: string;
  new_timestamp?: Date;
  new_status?: string;
}

/**
 * Check if running in PowerApps context
 */
export function isPowerAppsContext(): boolean {
  return typeof window !== 'undefined' && window.Xrm !== undefined;
}

/**
 * Get current contact ID from PowerApps form
 */
export function getCurrentContactId(): string | null {
  if (!isPowerAppsContext() || !window.Xrm?.Page) {
    return null;
  }
  
  try {
    return window.Xrm.Page.data.entity.getId();
  } catch (error) {
    console.error('Failed to get contact ID:', error);
    return null;
  }
}

/**
 * Get contact data from PowerApps form context
 * Reads all contact fields from Xrm.Page.data.entity.attributes
 * Returns mock data in development mode (when not in PowerApps context)
 */
export function getContactDataFromForm(): Contact | null {
  // Development mode - return mock data for testing
  if (!isPowerAppsContext() || !window.Xrm?.Page) {
    return {
      fullname: "Jane Smith",
      firstname: "Jane",
      lastname: "Smith",
      emailaddress1: "jane.smith@example.com",
      mobilephone: "+1-555-0123",
      parentcustomerid: "ACME Corporation",
      new_linkedinprofile: "https://www.linkedin.com/in/janesmith",
    };
  }

  try {
    const entity = window.Xrm.Page.data.entity;
    const attributes = entity.attributes;

    // Helper function to safely get attribute value
    const getAttributeValue = (attributeName: string): any => {
      const attribute = attributes.get(attributeName);
      return attribute ? attribute.getValue() : undefined;
    };

    // Handle lookup fields (parentcustomerid)
    const parentCustomerLookup = getAttributeValue('parentcustomerid');
    const parentCustomerValue = parentCustomerLookup 
      ? (Array.isArray(parentCustomerLookup) && parentCustomerLookup.length > 0 
          ? parentCustomerLookup[0].name 
          : parentCustomerLookup?.name)
      : undefined;

    const contact: Contact = {
      fullname: getAttributeValue('fullname') || '',
      firstname: getAttributeValue('firstname') || '',
      lastname: getAttributeValue('lastname') || '',
      emailaddress1: getAttributeValue('emailaddress1'),
      mobilephone: getAttributeValue('mobilephone'),
      parentcustomerid: parentCustomerValue,
      new_linkedinprofile: getAttributeValue('new_linkedinprofile'),
    };

    return contact;
  } catch (error) {
    console.error('Failed to get contact data from form:', error);
    return null;
  }
}

/**
 * Save enrichment history to Dataverse
 */
export async function saveEnrichmentHistory(data: {
  contactId: string;
  mode: string;
  providers: string[];
  results: any;
  status: 'success' | 'partial' | 'failed';
}): Promise<string | null> {
  if (!isPowerAppsContext()) {
    console.log('Development mode - would save enrichment history:', data);
    return null;
  }

  try {
    const record = {
      'new_contactid@odata.bind': `/contacts(${normalizeGuid(data.contactId)})`,
      new_enrichmentmode: data.mode,
      new_providerlist: JSON.stringify(data.providers),
      new_resultsjson: JSON.stringify(data.results),
      new_timestamp: new Date(),
      new_status: data.status,
    };

    const result = await window.Xrm!.WebApi.createRecord('new_enrichmenthistory', record);
    return result.id;
  } catch (error) {
    console.error('Failed to save enrichment history:', error);
    throw error;
  }
}

/**
 * Get enrichment history for current contact
 */
export async function getEnrichmentHistory(
  contactId: string,
  limit = 10
): Promise<EnrichmentHistory[]> {
  if (!isPowerAppsContext()) {
    console.log('Development mode - would fetch enrichment history for:', contactId);
    return [];
  }

  try {
    const options = `?$filter=_new_contactid_value eq guid'${normalizeGuid(contactId)}'&$orderby=new_timestamp desc&$top=${limit}`;
    const result = await window.Xrm!.WebApi.retrieveMultipleRecords(
      'new_enrichmenthistory',
      options
    );

    return result.entities || [];
  } catch (error) {
    console.error('Failed to get enrichment history:', error);
    return [];
  }
}

/**
 * Check cache for recent enrichment
 */
export async function getCachedEnrichment(
  contactId: string,
  provider: string
): Promise<any | null> {
  if (!isPowerAppsContext()) {
    return null;
  }

  try {
    const now = new Date().toISOString();
    const options = `?$filter=_new_contactid_value eq guid'${normalizeGuid(contactId)}' and new_provider eq '${provider}' and new_cacheexpiry gt ${now}&$top=1`;
    
    const result = await window.Xrm!.WebApi.retrieveMultipleRecords(
      'new_enrichmentcache',
      options
    );

    if (result.entities && result.entities.length > 0) {
      const cached = result.entities[0];
      return JSON.parse(cached.new_resultsjson || '{}');
    }

    return null;
  } catch (error) {
    console.error('Failed to check cache:', error);
    return null;
  }
}

/**
 * Save to cache
 */
export async function saveToCache(data: {
  contactId: string;
  provider: string;
  results: any;
  ttlMinutes?: number;
}): Promise<void> {
  if (!isPowerAppsContext()) {
    console.log('Development mode - would cache:', data);
    return;
  }

  try {
    const cacheExpiry = new Date();
    cacheExpiry.setMinutes(cacheExpiry.getMinutes() + (data.ttlMinutes || 60));

    const record = {
      'new_contactid@odata.bind': `/contacts(${normalizeGuid(data.contactId)})`,
      new_provider: data.provider,
      new_resultsjson: JSON.stringify(data.results),
      new_cacheexpiry: cacheExpiry,
      new_timestamp: new Date(),
    };

    await window.Xrm!.WebApi.createRecord('new_enrichmentcache', record);
  } catch (error) {
    console.error('Failed to save cache:', error);
  }
}

/**
 * Update contact with enriched data
 */
export async function updateContactData(
  contactId: string,
  updates: {
    emailaddress1?: string;
    mobilephone?: string;
  }
): Promise<void> {
  if (!isPowerAppsContext()) {
    console.log('Development mode - would update contact:', contactId, updates);
    return;
  }

  try {
    await window.Xrm!.WebApi.updateRecord('contact', normalizeGuid(contactId), updates);
  } catch (error) {
    console.error('Failed to update contact:', error);
    throw error;
  }
}

/**
 * Create audit log entry
 */
export async function createAuditLog(data: {
  contactId: string;
  operation: string;
  details: any;
}): Promise<void> {
  if (!isPowerAppsContext()) {
    console.log('Development mode - would create audit log:', data);
    return;
  }

  try {
    const record = {
      'new_contactid@odata.bind': `/contacts(${normalizeGuid(data.contactId)})`,
      new_operation: data.operation,
      new_details: JSON.stringify(data.details),
      new_timestamp: new Date(),
    };

    await window.Xrm!.WebApi.createRecord('new_auditlog', record);
  } catch (error) {
    console.error('Failed to create audit log:', error);
  }
}

/**
 * Clear all cache records for a contact
 */
export async function clearContactCache(contactId: string): Promise<void> {
  if (!isPowerAppsContext()) {
    console.log('Development mode - would clear cache for contact:', contactId);
    return;
  }

  try {
    const options = `?$filter=_new_contactid_value eq guid'${normalizeGuid(contactId)}'`;
    const result = await window.Xrm!.WebApi.retrieveMultipleRecords(
      'new_enrichmentcache',
      options
    );

    if (result.entities && result.entities.length > 0) {
      for (const entity of result.entities) {
        await window.Xrm!.WebApi.deleteRecord(
          'new_enrichmentcache',
          entity.new_enrichmentcacheid
        );
      }
    }
  } catch (error) {
    console.error('Failed to clear cache:', error);
    throw error;
  }
}

// In-memory storage for phone numbers in development mode
let devPhoneNumbers: Array<{
  cr533_phonenumbersid: string;
  cr533_phonenumber: string;
  cr533_relatedcontact: string;
  cr533_isvalidated: boolean;
  cr533_validationstatus: 'valid' | 'invalid' | 'pending';
}> = [];

/**
 * Get all phone numbers for a contact
 */
export async function getPhoneNumbersForContact(contactId: string): Promise<Array<{
  cr533_phonenumbersid: string;
  cr533_phonenumber: string;
  cr533_relatedcontact: string;
  cr533_isvalidated: boolean;
  cr533_validationstatus: 'valid' | 'invalid' | 'pending';
}>> {
  if (!isPowerAppsContext()) {
    console.log('Development mode - returning in-memory phone numbers for:', contactId);
    return devPhoneNumbers.filter(p => p.cr533_relatedcontact === contactId);
  }

  try {
    const options = `?$filter=_cr533_relatedcontact_value eq guid'${normalizeGuid(contactId)}'&$orderby=createdon desc`;
    const result = await window.Xrm!.WebApi.retrieveMultipleRecords(
      'cr533_phonenumbers',
      options
    );

    return result.entities || [];
  } catch (error) {
    console.error('Failed to get phone numbers:', error);
    return [];
  }
}

/**
 * Add a phone number for a contact
 */
export async function addPhoneNumber(data: {
  contactId: string;
  phoneNumber: string;
  isValidated: boolean;
  validationStatus: 'valid' | 'invalid' | 'pending';
}): Promise<string> {
  if (!isPowerAppsContext()) {
    console.log('Development mode - adding phone number to memory:', data);
    const id = `dev-phone-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    devPhoneNumbers.push({
      cr533_phonenumbersid: id,
      cr533_phonenumber: data.phoneNumber,
      cr533_relatedcontact: data.contactId,
      cr533_isvalidated: data.isValidated,
      cr533_validationstatus: data.validationStatus,
    });
    return id;
  }

  try {
    const record = {
      'cr533_relatedcontact@odata.bind': `/contacts(${normalizeGuid(data.contactId)})`,
      cr533_phonenumber: data.phoneNumber,
      cr533_isvalidated: data.isValidated,
      cr533_validationstatus: data.validationStatus,
    };

    const result = await window.Xrm!.WebApi.createRecord('cr533_phonenumbers', record);
    return result.id;
  } catch (error) {
    console.error('Failed to add phone number:', error);
    throw error;
  }
}
