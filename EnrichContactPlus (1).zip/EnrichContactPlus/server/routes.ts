import type { Express } from "express";
import { createServer, type Server } from "http";
import {
  enrichContactRequestSchema,
  searchExecutiveAssistantRequestSchema,
  validatePhoneRequestSchema,
  validatePhoneResponseSchema,
  type EnrichmentResult,
} from "@shared/schema";
import {
  enrichForceAll,
  enrichWaterfall,
  enrichWithProvider,
  type Provider,
} from "./lib/enrichment-providers";
import { searchExecutiveAssistant } from "./lib/openai";
import { validatePhoneNumber } from "./lib/clearoutphone";

// In-memory storage for call tracking
// Key format: `${aircallNumber}:${contactPhone}` -> count
const callTrackingMap = new Map<string, number>();

export async function registerRoutes(app: Express): Promise<Server> {
  // Enrich contact endpoint
  app.post("/api/enrich", async (req, res) => {
    try {
      const requestData = enrichContactRequestSchema.parse(req.body);
      const { contact, mode, providers } = requestData;

      const allProviders: Provider[] = providers || [
        'apollo',
        'bettercontact',
        'fullenrich',
        'cognism',
        'clay',
      ];

      let results: EnrichmentResult[] = [];

      if (mode === 'force_all') {
        // Run all providers in parallel
        const enrichmentResults = await enrichForceAll(contact, allProviders);
        
        results = allProviders.map((provider) => {
          const result = enrichmentResults.get(provider);
          if (result?.data) {
            return {
              provider,
              status: 'success' as const,
              emails: result.data.emails,
              mobilePhones: result.data.mobilePhones,
              timestamp: new Date().toISOString(),
            };
          } else {
            return {
              provider,
              status: 'error' as const,
              emails: [],
              mobilePhones: [],
              error: result?.error || 'Unknown error',
            };
          }
        });
      } else if (mode === 'waterfall') {
        // Try providers sequentially
        const result = await enrichWaterfall(contact, allProviders);
        
        if (result) {
          results = [{
            provider: result.provider,
            status: 'success' as const,
            emails: result.data.emails,
            mobilePhones: result.data.mobilePhones,
            timestamp: new Date().toISOString(),
          }];
        } else {
          results = allProviders.map((provider) => ({
            provider,
            status: 'no_results' as const,
            emails: [],
            mobilePhones: [],
          }));
        }
      } else if (mode === 'select_source') {
        // Run selected providers in parallel
        const enrichmentResults = await enrichForceAll(contact, allProviders);
        
        results = allProviders.map((provider) => {
          const result = enrichmentResults.get(provider);
          if (result?.data) {
            return {
              provider,
              status: 'success' as const,
              emails: result.data.emails,
              mobilePhones: result.data.mobilePhones,
              timestamp: new Date().toISOString(),
            };
          } else {
            return {
              provider,
              status: 'error' as const,
              emails: [],
              mobilePhones: [],
              error: result?.error || 'Unknown error',
            };
          }
        });
      }

      res.json({ results });
    } catch (error) {
      console.error('Enrichment error:', error);
      res.status(400).json({
        error: error instanceof Error ? error.message : 'Enrichment failed',
      });
    }
  });

  // Search executive assistant endpoint
  app.post("/api/search-ea", async (req, res) => {
    try {
      const requestData = searchExecutiveAssistantRequestSchema.parse(req.body);
      const { contact } = requestData;

      const result = await searchExecutiveAssistant({
        fullname: contact.fullname,
        firstname: contact.firstname || '',
        lastname: contact.lastname || '',
        linkedinProfile: contact.new_linkedinprofile,
      });

      if (result.name) {
        res.json({
          assistant: {
            name: result.name,
            email: result.email,
            phone: result.phone,
            confidence: result.confidence,
          },
        });
      } else {
        res.json({
          error: "No executive assistant information found",
        });
      }
    } catch (error) {
      console.error('EA search error:', error);
      res.status(400).json({
        error: error instanceof Error ? error.message : 'EA search failed',
      });
    }
  });

  // Validate phone number endpoint
  app.post("/api/validate-phone", async (req, res) => {
    try {
      const requestData = validatePhoneRequestSchema.parse(req.body);
      const { phoneNumber } = requestData;

      const result = await validatePhoneNumber(phoneNumber);

      // Validate the response structure using the schema
      const validatedResponse = validatePhoneResponseSchema.parse({
        isValid: result.isValid,
        details: result.details,
      });

      res.json(validatedResponse);
    } catch (error) {
      console.error('Phone validation error:', error);
      
      // Return structured error response with isValid: false
      const errorResponse = validatePhoneResponseSchema.parse({
        isValid: false,
        details: {
          error: error instanceof Error ? error.message : 'Phone validation failed',
        },
      });
      
      res.status(400).json(errorResponse);
    }
  });

  // Call tracking endpoints
  // Increment call count for a specific Aircall number + contact phone combination
  app.post("/api/call-tracking/increment", async (req, res) => {
    try {
      const aircallNumber: string | undefined = req.body.aircallNumber;
      const contactPhone: string | undefined = req.body.contactPhone;
      
      if (!aircallNumber || !contactPhone) {
        return res.status(400).json({
          error: "Both aircallNumber and contactPhone are required",
        });
      }

      const key = `${aircallNumber}:${contactPhone}`;
      const currentCount = callTrackingMap.get(key) || 0;
      const newCount = currentCount + 1;
      callTrackingMap.set(key, newCount);

      res.json({ 
        success: true, 
        count: newCount,
        aircallNumber,
        contactPhone,
      });
    } catch (error) {
      console.error('Call tracking increment error:', error);
      res.status(400).json({
        error: error instanceof Error ? error.message : 'Failed to increment call count',
      });
    }
  });

  // Get call counts for a specific contact phone number
  app.get("/api/call-tracking/:contactPhone", async (req, res) => {
    try {
      const { contactPhone } = req.params;
      
      if (!contactPhone) {
        return res.status(400).json({
          error: "Contact phone is required",
        });
      }

      // Mock Aircall numbers
      const aircallNumbers = [
        { number: "+1 (555) 123-4567", label: "Main Office" },
        { number: "+1 (555) 987-6543", label: "Sales Line" },
        { number: "+1 (555) 456-7890", label: "Support Line" },
      ];

      // Get call counts for each Aircall number with this contact
      const callCounts = aircallNumbers.map(aircall => {
        const key = `${aircall.number}:${contactPhone}`;
        const count = callTrackingMap.get(key) || 0;
        
        return {
          aircallNumber: aircall.number,
          label: aircall.label,
          count,
        };
      });

      res.json({ 
        contactPhone,
        callCounts,
      });
    } catch (error) {
      console.error('Call tracking fetch error:', error);
      res.status(400).json({
        error: error instanceof Error ? error.message : 'Failed to fetch call counts',
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
