import OpenAI from "openai";
import { z } from "zod";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Zod schema for validating OpenAI response
const eaResponseSchema = z.object({
  name: z.string().optional(),
  email: z.string().email().optional(),
  phone: z.string().optional(),
  confidence: z.number().min(0).max(1).optional(),
}).strict();

export async function searchExecutiveAssistant(contactInfo: {
  fullname: string;
  firstname: string;
  lastname: string;
  companyName?: string;
  linkedinProfile?: string;
}): Promise<{
  name?: string;
  email?: string;
  phone?: string;
  confidence?: number;
}> {
  try {
    const prompt = `You are an expert at finding executive assistant information for business contacts.

Given the following contact information:
- Name: ${contactInfo.fullname}
- First Name: ${contactInfo.firstname}
- Last Name: ${contactInfo.lastname}
${contactInfo.companyName ? `- Company: ${contactInfo.companyName}` : ''}
${contactInfo.linkedinProfile ? `- LinkedIn: ${contactInfo.linkedinProfile}` : ''}

Search your knowledge and provide the most likely executive assistant (EA) for this person. Return your response in JSON format with the following structure:
{
  "name": "EA full name",
  "email": "EA email if known",
  "phone": "EA phone if known",
  "confidence": 0.0 to 1.0 (your confidence in this information)
}

If you cannot find any information, return an empty object: {}`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are a professional business intelligence assistant. Provide accurate, professional information only. Always respond with valid JSON.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 500,
    });

    const rawContent = response.choices[0].message.content || "{}";
    const parsedJson = JSON.parse(rawContent);
    
    // Validate response against schema
    const validatedResult = eaResponseSchema.parse(parsedJson);
    return validatedResult;
  } catch (error) {
    if (error instanceof z.ZodError) {
      console.error("OpenAI response validation error:", error.errors);
      throw new Error("Invalid response format from AI search");
    }
    console.error("OpenAI EA search error:", error);
    throw new Error("Failed to search for executive assistant");
  }
}
