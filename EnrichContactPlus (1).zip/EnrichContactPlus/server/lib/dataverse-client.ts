import fetch from "node-fetch";

/**
 * Dataverse Web API Client
 * 
 * This client handles communication with Microsoft Dataverse (Power Platform)
 * for storing enrichment history, cache, and audit logs.
 * 
 * Note: In production, authentication should use Azure AD tokens.
 * For development, this is a reference implementation.
 */

/**
 * Normalize GUID by removing braces
 * PowerApps provides GUIDs with braces, but Dataverse OData requires them without
 */
function normalizeGuid(id: string): string {
  return id.replace(/[{}]/g, '');
}

export interface DataverseConfig {
  instanceUrl: string; // e.g., https://org.crm.dynamics.com
  accessToken?: string; // OAuth token from PowerApps context
}

export interface EnrichmentHistoryRecord {
  new_contactid?: string; // Lookup to Contact (GUID)
  new_enrichmentmode?: string; // 'force_all' | 'waterfall' | 'select_source'
  new_providerlist?: string; // JSON array of provider names
  new_resultsjson?: string; // JSON string of results
  new_timestamp?: Date;
  new_status?: string; // 'success' | 'partial' | 'failed'
}

export interface EnrichmentCacheRecord {
  new_contactid?: string; // Lookup to Contact (GUID)
  new_provider?: string; // Provider name
  new_resultsjson?: string; // JSON string of enrichment data
  new_cacheexpiry?: Date; // When cache expires
  new_timestamp?: Date;
}

export interface AuditLogRecord {
  new_contactid?: string; // Lookup to Contact (GUID)
  new_operation?: string; // e.g., 'enrichment', 'update', 'search_ea'
  new_userid?: string; // Lookup to User (GUID)
  new_details?: string; // JSON details
  new_timestamp?: Date;
}

export class DataverseClient {
  private config: DataverseConfig;
  private apiVersion = "v9.2";

  constructor(config: DataverseConfig) {
    this.config = config;
  }

  /**
   * Create enrichment history record
   */
  async createEnrichmentHistory(record: EnrichmentHistoryRecord): Promise<string> {
    const url = `${this.config.instanceUrl}/api/data/${this.apiVersion}/new_enrichmenthistories`;
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.config.accessToken}`,
        'Content-Type': 'application/json',
        'OData-MaxVersion': '4.0',
        'OData-Version': '4.0',
      },
      body: JSON.stringify({
        'new_contactid@odata.bind': `/contacts(${normalizeGuid(record.new_contactid!)})`,
        new_enrichmentmode: record.new_enrichmentmode,
        new_providerlist: record.new_providerlist,
        new_resultsjson: record.new_resultsjson,
        new_timestamp: record.new_timestamp?.toISOString(),
        new_status: record.new_status,
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Failed to create enrichment history: ${error}`);
    }

    const location = response.headers.get('OData-EntityId');
    const id = location?.match(/\(([^)]+)\)/)?.[1] || '';
    return id;
  }

  /**
   * Get enrichment history for a contact
   */
  async getEnrichmentHistory(contactId: string, limit = 10): Promise<EnrichmentHistoryRecord[]> {
    const url = `${this.config.instanceUrl}/api/data/${this.apiVersion}/new_enrichmenthistories`;
    const filter = `_new_contactid_value eq guid'${normalizeGuid(contactId)}'`;
    const orderby = 'new_timestamp desc';

    const response = await fetch(
      `${url}?$filter=${encodeURIComponent(filter)}&$orderby=${encodeURIComponent(orderby)}&$top=${limit}`,
      {
        headers: {
          'Authorization': `Bearer ${this.config.accessToken}`,
          'OData-MaxVersion': '4.0',
          'OData-Version': '4.0',
        },
      }
    );

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Failed to get enrichment history: ${error}`);
    }

    const data: any = await response.json();
    return data.value || [];
  }

  /**
   * Check cache for recent enrichment
   */
  async getCachedEnrichment(contactId: string, provider: string): Promise<EnrichmentCacheRecord | null> {
    const url = `${this.config.instanceUrl}/api/data/${this.apiVersion}/new_enrichmentcaches`;
    const now = new Date().toISOString();
    const filter = `_new_contactid_value eq guid'${normalizeGuid(contactId)}' and new_provider eq '${provider}' and new_cacheexpiry gt ${now}`;

    const response = await fetch(
      `${url}?$filter=${encodeURIComponent(filter)}&$top=1`,
      {
        headers: {
          'Authorization': `Bearer ${this.config.accessToken}`,
          'OData-MaxVersion': '4.0',
          'OData-Version': '4.0',
        },
      }
    );

    if (!response.ok) {
      return null;
    }

    const data: any = await response.json();
    return data.value?.[0] || null;
  }

  /**
   * Create or update cache record
   */
  async upsertCache(record: EnrichmentCacheRecord): Promise<void> {
    // Check if cache exists
    const existing = await this.getCachedEnrichment(
      record.new_contactid!,
      record.new_provider!
    );

    if (existing) {
      // Update existing
      const url = `${this.config.instanceUrl}/api/data/${this.apiVersion}/new_enrichmentcaches(${(existing as any).new_enrichmentcacheid})`;
      
      await fetch(url, {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${this.config.accessToken}`,
          'Content-Type': 'application/json',
          'OData-MaxVersion': '4.0',
          'OData-Version': '4.0',
        },
        body: JSON.stringify({
          new_resultsjson: record.new_resultsjson,
          new_cacheexpiry: record.new_cacheexpiry?.toISOString(),
          new_timestamp: new Date().toISOString(),
        }),
      });
    } else {
      // Create new
      const url = `${this.config.instanceUrl}/api/data/${this.apiVersion}/new_enrichmentcaches`;
      
      await fetch(url, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.config.accessToken}`,
          'Content-Type': 'application/json',
          'OData-MaxVersion': '4.0',
          'OData-Version': '4.0',
        },
        body: JSON.stringify({
          'new_contactid@odata.bind': `/contacts(${normalizeGuid(record.new_contactid!)})`,
          new_provider: record.new_provider,
          new_resultsjson: record.new_resultsjson,
          new_cacheexpiry: record.new_cacheexpiry?.toISOString(),
          new_timestamp: new Date().toISOString(),
        }),
      });
    }
  }

  /**
   * Create audit log entry
   */
  async createAuditLog(record: AuditLogRecord): Promise<void> {
    const url = `${this.config.instanceUrl}/api/data/${this.apiVersion}/new_auditlogs`;
    
    await fetch(url, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.config.accessToken}`,
        'Content-Type': 'application/json',
        'OData-MaxVersion': '4.0',
        'OData-Version': '4.0',
      },
      body: JSON.stringify({
        'new_contactid@odata.bind': `/contacts(${normalizeGuid(record.new_contactid!)})`,
        'new_userid@odata.bind': record.new_userid ? `/systemusers(${normalizeGuid(record.new_userid)})` : undefined,
        new_operation: record.new_operation,
        new_details: record.new_details,
        new_timestamp: new Date().toISOString(),
      }),
    });
  }

  /**
   * Update Contact entity with enriched data
   */
  async updateContact(contactId: string, updates: {
    emailaddress1?: string;
    mobilephone?: string;
  }): Promise<void> {
    const url = `${this.config.instanceUrl}/api/data/${this.apiVersion}/contacts(${normalizeGuid(contactId)})`;
    
    const response = await fetch(url, {
      method: 'PATCH',
      headers: {
        'Authorization': `Bearer ${this.config.accessToken}`,
        'Content-Type': 'application/json',
        'OData-MaxVersion': '4.0',
        'OData-Version': '4.0',
      },
      body: JSON.stringify(updates),
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Failed to update contact: ${error}`);
    }
  }
}

/**
 * Helper to get Dataverse client from PowerApps context
 * In production, the web resource would obtain the access token from the parent PowerApps form
 */
export function createDataverseClient(
  instanceUrl?: string,
  accessToken?: string
): DataverseClient | null {
  // In development, return null if no config provided
  if (!instanceUrl || !accessToken) {
    console.warn('Dataverse client not configured - running in development mode');
    return null;
  }

  return new DataverseClient({ instanceUrl, accessToken });
}
