import type { Contact } from "@shared/schema";
import fetch from "node-fetch";

export type Provider = 'apollo' | 'bettercontact' | 'fullenrich' | 'cognism' | 'clay';

export interface EnrichmentData {
  emails: string[];
  mobilePhones: string[];
}

// Rate limiting helper
class RateLimiter {
  private lastCall: Record<Provider, number> = {} as Record<Provider, number>;
  private minDelay = 1000; // 1 second between calls

  async throttle(provider: Provider): Promise<void> {
    const now = Date.now();
    const last = this.lastCall[provider] || 0;
    const elapsed = now - last;
    
    if (elapsed < this.minDelay) {
      await new Promise(resolve => setTimeout(resolve, this.minDelay - elapsed));
    }
    
    this.lastCall[provider] = Date.now();
  }
}

const rateLimiter = new RateLimiter();

// Helper function to poll for results from async APIs
async function pollForResults(
  url: string,
  headers: HeadersInit,
  maxAttempts: number = 30,  // Changed from 10 to 30 (90 seconds total)
  intervalMs: number = 3000
): Promise<any> {
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    // Wait before polling (except on first attempt)
    if (attempt > 1) {
      await new Promise(resolve => setTimeout(resolve, intervalMs));
    }
    
    try {
      const response = await fetch(url, {
        method: 'GET',
        headers,
      });

      if (response.status === 429) {
        // Rate limited, wait and retry
        console.log(`Polling attempt ${attempt}/${maxAttempts} - Rate limited, waiting longer...`);
        await new Promise(resolve => setTimeout(resolve, intervalMs * 2));
        continue;
      }

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Polling attempt ${attempt}/${maxAttempts} - HTTP error (${response.status}): ${errorText}`);
        throw new Error(`Polling error (${response.status}): ${errorText}`);
      }

      const data = await response.json() as any;
      
      // Add detailed logging
      console.log(`Polling attempt ${attempt}/${maxAttempts} - Status: ${data.status || 'unknown'}`);
      
      // Check multiple possible completion statuses (case-insensitive)
      const completionStatuses = ['completed', 'complete', 'finished', 'done', 'success', 'ready', 'terminated'];
      if (data.status && completionStatuses.includes(data.status.toLowerCase())) {
        console.log('Enrichment completed successfully with status:', data.status);
        return data;
      }
      
      // Also check if we have result data even without expected status
      if (data.data && Array.isArray(data.data) && data.data.length > 0) {
        console.log('Found result data despite status being:', data.status);
        return data;
      }
      
      // Check for results field as well
      if (data.results && Array.isArray(data.results) && data.results.length > 0) {
        console.log('Found results data despite status being:', data.status);
        return data;
      }
      
      // Check for datas field (FullEnrich uses this)
      if (data.datas && Array.isArray(data.datas) && data.datas.length > 0) {
        console.log('Found datas field despite status being:', data.status);
        return data;
      }
      
      // Check for failure statuses
      const failureStatuses = ['failed', 'error', 'failure', 'fail'];
      if (data.status && failureStatuses.includes(data.status.toLowerCase())) {
        throw new Error(`Enrichment failed: ${data.message || data.error || 'Unknown error'}`);
      }
      
      // Log the full response on every 5th attempt for debugging
      if (attempt % 5 === 0) {
        console.log('Polling response data:', JSON.stringify(data, null, 2));
      }
      
      // Still processing, continue to next attempt
    } catch (error) {
      console.error(`Polling attempt ${attempt}/${maxAttempts} failed:`, error);
      if (attempt === maxAttempts) {
        throw error;
      }
      // Wait before retrying on error
      await new Promise(resolve => setTimeout(resolve, intervalMs));
    }
  }
  
  throw new Error('Polling timeout - enrichment took too long to complete (90 seconds)');
}

// Helper function to extract company domain from company name
function extractCompanyDomain(company: string | undefined): string {
  if (!company) {
    return '';
  }
  
  // If it already looks like a domain, return it
  if (company.includes('.')) {
    return company.toLowerCase().replace(/^https?:\/\//, '').replace(/\/$/, '');
  }
  
  // Simple heuristic: lowercase, remove spaces and common suffixes, add .com
  const cleanName = company
    .toLowerCase()
    .replace(/\s+/g, '')
    .replace(/,?\s*(inc|llc|ltd|corp|corporation|company|co)\.?$/i, '');
  
  return cleanName ? `${cleanName}.com` : '';
}

// Retry helper
async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  maxRetries = 2,
  baseDelay = 1000
): Promise<T> {
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      if (i === maxRetries - 1) throw error;
      await new Promise(resolve => setTimeout(resolve, baseDelay * Math.pow(2, i)));
    }
  }
  throw new Error("Max retries exceeded");
}

// Apollo.io API
async function enrichWithApollo(contact: Contact): Promise<EnrichmentData> {
  const apiKey = process.env.APOLLO_API_KEY;
  if (!apiKey) {
    throw new Error("Apollo API key not configured");
  }

  await rateLimiter.throttle('apollo');

  return retryWithBackoff(async () => {
    const response = await fetch('https://api.apollo.io/v1/people/match', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Api-Key': apiKey,
      },
      body: JSON.stringify({
        first_name: contact.firstname,
        last_name: contact.lastname,
        email: contact.emailaddress1,
        linkedin_url: contact.new_linkedinprofile,
      }),
    });

    if (response.status === 429) {
      throw new Error("Rate limit exceeded - please try again later");
    }

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Apollo API error (${response.status}): ${errorText}`);
    }

    const data: any = await response.json();
    
    return {
      emails: data.person?.email ? [data.person.email] : [],
      mobilePhones: data.person?.phone_numbers || [],
    };
  });
}

// BetterContact API (Async pattern with polling)
async function enrichWithBetterContact(contact: Contact): Promise<EnrichmentData> {
  const apiKey = process.env.BETTERCONTACT_API_KEY;
  if (!apiKey) {
    throw new Error("BetterContact API key not configured");
  }

  await rateLimiter.throttle('bettercontact');

  return retryWithBackoff(async () => {
    try {
      console.log('BetterContact: Starting enrichment for', contact.firstname, contact.lastname);
      
      // Extract company domain from company name
      const companyDomain = extractCompanyDomain(contact.parentcustomerid);
      
      // Step 1: Submit async enrichment request
      const submitResponse = await fetch('https://app.bettercontact.rocks/api/v2/async', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-API-Key': apiKey,
        },
        body: JSON.stringify({
          data: [
            {
              first_name: contact.firstname || '',
              last_name: contact.lastname || '',
              company: contact.parentcustomerid || '',
              company_domain: companyDomain,
              linkedin_url: contact.new_linkedinprofile || '',
              custom_fields: {}
            }
          ],
          enrich_email_address: true,
          enrich_phone_number: true
        }),
      });

      if (submitResponse.status === 401 || submitResponse.status === 403) {
        throw new Error("BetterContact authentication failed - check API key");
      }

      if (submitResponse.status === 429) {
        throw new Error("Rate limit exceeded - please try again later");
      }

      if (!submitResponse.ok) {
        const errorText = await submitResponse.text();
        throw new Error(`BetterContact submit error (${submitResponse.status}): ${errorText}`);
      }

      const submitData: any = await submitResponse.json();
      const requestId = submitData.request_id || submitData.id;
      
      if (!requestId) {
        throw new Error('BetterContact: No request ID returned from async submission');
      }

      console.log('BetterContact: Request submitted, ID:', requestId);

      // Step 2: Poll for results (authentication via header, not query param)
      const pollUrl = `https://app.bettercontact.rocks/api/v2/async/${requestId}`;
      const result = await pollForResults(
        pollUrl,
        {
          'Content-Type': 'application/json',
          'X-API-Key': apiKey,
        },
        30, // max 30 attempts (90 seconds total)
        3000 // 3 second intervals
      );

      console.log('BetterContact: Enrichment completed', result);

      // Extract emails and phones from the result
      const emails: Set<string> = new Set();
      const mobilePhones: Set<string> = new Set();

      // BetterContact response structure:
      // {
      //   "status": "terminated",
      //   "data": [
      //     {
      //       "enriched": true,
      //       "contact_email_address": "email@example.com",
      //       "contact_phone_number": "+1234567890"
      //     }
      //   ]
      // }
      
      if (result.data && Array.isArray(result.data)) {
        console.log(`BetterContact: Processing ${result.data.length} contact results`);
        
        for (const contact of result.data) {
          // Only process enriched contacts
          if (contact.enriched) {
            console.log('BetterContact: Found enriched contact:', JSON.stringify(contact, null, 2));
            
            // Primary field names used by BetterContact
            if (contact.contact_email_address) {
              emails.add(contact.contact_email_address);
            }
            if (contact.contact_phone_number) {
              mobilePhones.add(contact.contact_phone_number);
            }
            
            // Check for alternative field names
            if (contact.email_address) {
              emails.add(contact.email_address);
            }
            if (contact.email) {
              emails.add(contact.email);
            }
            if (contact.phone_number) {
              mobilePhones.add(contact.phone_number);
            }
            if (contact.mobile_phone) {
              mobilePhones.add(contact.mobile_phone);
            }
            if (contact.phone) {
              mobilePhones.add(contact.phone);
            }
            
            // Handle array formats if present
            if (contact.emails && Array.isArray(contact.emails)) {
              contact.emails.forEach((email: string) => emails.add(email));
            }
            if (contact.phones && Array.isArray(contact.phones)) {
              contact.phones.forEach((phone: string) => mobilePhones.add(phone));
            }
          } else {
            console.log('BetterContact: Contact not enriched, skipping');
          }
        }
      }

      console.log(`BetterContact: Found ${emails.size} emails and ${mobilePhones.size} phone numbers`);

      // Convert Sets to arrays
      return {
        emails: Array.from(emails),
        mobilePhones: Array.from(mobilePhones),
      };
    } catch (error) {
      console.error('BetterContact enrichment error:', error);
      // Return empty arrays on failure (graceful degradation)
      if (error instanceof Error && error.message.includes('authentication')) {
        throw error; // Re-throw authentication errors
      }
      return { emails: [], mobilePhones: [] };
    }
  });
}

// FullEnrich API (Bulk enrichment with polling)
async function enrichWithFullEnrich(contact: Contact): Promise<EnrichmentData> {
  const apiKey = process.env.FULLENRICH_API_KEY;
  if (!apiKey) {
    throw new Error("FullEnrich API key not configured");
  }

  await rateLimiter.throttle('fullenrich');

  return retryWithBackoff(async () => {
    try {
      console.log('FullEnrich: Starting enrichment for', contact.firstname, contact.lastname);
      
      // Extract company domain from company name
      const companyDomain = extractCompanyDomain(contact.parentcustomerid);
      
      // Step 1: Submit bulk enrichment request
      const enrichmentName = `Enrich for ${contact.firstname} ${contact.lastname} - ${contact.parentcustomerid || 'Unknown'}`;
      
      const submitResponse = await fetch('https://app.fullenrich.com/api/v1/contact/enrich/bulk', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          name: enrichmentName,
          datas: [
            {
              firstname: contact.firstname || '',
              lastname: contact.lastname || '',
              domain: companyDomain,
              company_name: contact.parentcustomerid || '',
              linkedin_url: contact.new_linkedinprofile || '',
              enrich_fields: ['contact.emails', 'contact.phones']
            }
          ]
        }),
      });

      if (submitResponse.status === 401 || submitResponse.status === 403) {
        throw new Error("FullEnrich authentication failed - check API key");
      }

      if (submitResponse.status === 429) {
        throw new Error("Rate limit exceeded - please try again later");
      }

      if (!submitResponse.ok) {
        const errorText = await submitResponse.text();
        throw new Error(`FullEnrich submit error (${submitResponse.status}): ${errorText}`);
      }

      const submitData: any = await submitResponse.json();
      const enrichmentId = submitData.enrichment_id || submitData.id;
      
      if (!enrichmentId) {
        throw new Error('FullEnrich: No enrichment ID returned from bulk submission');
      }

      console.log('FullEnrich: Request submitted, ID:', enrichmentId);

      // Step 2: Poll for results
      const pollUrl = `https://app.fullenrich.com/api/v1/contact/enrich/bulk/${enrichmentId}`;
      const result = await pollForResults(
        pollUrl,
        {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        30, // max 30 attempts (90 seconds total)
        3000 // 3 second intervals
      );

      console.log('FullEnrich: Enrichment completed', result);

      // Extract emails and phones from the result
      const emails: string[] = [];
      const mobilePhones: string[] = [];

      // FullEnrich returns enriched data in the datas array
      if (result.datas && Array.isArray(result.datas)) {
        for (const item of result.datas) {
          // Extract emails
          if (item.contact?.emails && Array.isArray(item.contact.emails)) {
            for (const email of item.contact.emails) {
              if (typeof email === 'string') {
                emails.push(email);
              } else if (email.email) {
                emails.push(email.email);
              }
            }
          }
          
          // Extract phone numbers
          if (item.contact?.phones && Array.isArray(item.contact.phones)) {
            for (const phone of item.contact.phones) {
              if (typeof phone === 'string') {
                mobilePhones.push(phone);
              } else if (phone.number) {
                mobilePhones.push(phone.number);
              } else if (phone.phone) {
                mobilePhones.push(phone.phone);
              }
            }
          }
          
          // Check for alternative field names
          if (item.emails && Array.isArray(item.emails)) {
            emails.push(...item.emails);
          }
          if (item.phones && Array.isArray(item.phones)) {
            mobilePhones.push(...item.phones);
          }
        }
      }

      // Remove duplicates
      return {
        emails: Array.from(new Set(emails)),
        mobilePhones: Array.from(new Set(mobilePhones)),
      };
    } catch (error) {
      console.error('FullEnrich enrichment error:', error);
      // Return empty arrays on failure (graceful degradation)
      if (error instanceof Error && error.message.includes('authentication')) {
        throw error; // Re-throw authentication errors
      }
      return { emails: [], mobilePhones: [] };
    }
  });
}

// Cognism API (Two-step search and redeem process)
async function enrichWithCognism(contact: Contact): Promise<EnrichmentData> {
  const apiKey = process.env.COGNISM_API_KEY;
  if (!apiKey) {
    throw new Error("Cognism API key not configured");
  }

  await rateLimiter.throttle('cognism');

  return retryWithBackoff(async () => {
    try {
      console.log('Cognism: Starting enrichment for', contact.firstname, contact.lastname);
      
      // Step 1: Search for contacts
      const searchResponse = await fetch('https://app.cognism.com/api/search/contact/search', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          firstName: contact.firstname || '',
          lastName: contact.lastname || '',
          account: {
            names: contact.parentcustomerid ? [contact.parentcustomerid] : []
          },
          mobilePhoneNumbers: { highPlus: true },
          emailQuality: { highPlus: true }
        }),
      });

      if (searchResponse.status === 401 || searchResponse.status === 403) {
        throw new Error("Cognism authentication failed - check API key");
      }

      if (searchResponse.status === 429) {
        throw new Error("Rate limit exceeded - please try again later");
      }

      if (!searchResponse.ok) {
        const errorText = await searchResponse.text();
        throw new Error(`Cognism search error (${searchResponse.status}): ${errorText}`);
      }

      const searchData: any = await searchResponse.json();
      console.log('Cognism: Search results:', searchData);
      
      // Check if we found any contacts
      if (!searchData.results || searchData.results.length === 0) {
        console.log('Cognism: No contacts found in search');
        return { emails: [], mobilePhones: [] };
      }

      // First, try to extract email/phone from search results directly
      const searchEmails: Set<string> = new Set();
      const searchPhones: Set<string> = new Set();

      for (const result of searchData.results || []) {
        // Try to extract email from search results
        if (result.email) {
          searchEmails.add(result.email);
        }
        if (result.hasEmail && result.emailAddress) {
          searchEmails.add(result.emailAddress);
        }
        if (result.emails && Array.isArray(result.emails)) {
          result.emails.forEach((email: string) => searchEmails.add(email));
        }
        
        // Try to extract phone from search results
        if (result.mobilePhone) {
          searchPhones.add(result.mobilePhone);
        }
        if (result.hasMobilePhoneNumbers && result.mobilePhoneNumber) {
          searchPhones.add(result.mobilePhoneNumber);
        }
        if (result.phoneNumbers && Array.isArray(result.phoneNumbers)) {
          result.phoneNumbers.forEach((phone: any) => {
            if (typeof phone === 'string') {
              searchPhones.add(phone);
            } else if (phone.type === 'mobile' && phone.number) {
              searchPhones.add(phone.number);
            }
          });
        }
      }

      // If we found data in search results, use it directly
      if (searchEmails.size > 0 || searchPhones.size > 0) {
        console.log('Cognism: Using data from search results directly');
        return {
          emails: Array.from(searchEmails),
          mobilePhones: Array.from(searchPhones)
        };
      }

      // Extract contact IDs from search results
      const contactIds = searchData.results
        .filter((result: any) => result.id)
        .map((result: any) => result.id);

      if (contactIds.length === 0) {
        console.log('Cognism: No contact IDs found in search results');
        return { emails: [], mobilePhones: [] };
      }

      console.log('Cognism: Found contact IDs:', contactIds);

      // Step 2: Try to redeem full contact details (handle 405 error gracefully)
      let redeemData: any = null;
      const redeemEndpoints = [
        '/api/redeem/contacts',
        '/api/contact/redeem',
        '/api/contacts/redeem'
      ];
      
      for (const endpoint of redeemEndpoints) {
        try {
          const redeemResponse = await fetch(`https://app.cognism.com${endpoint}`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${apiKey}`,
            },
            body: JSON.stringify({
              contactIds: contactIds,
            }),
          });

          if (redeemResponse.status === 405) {
            console.log(`Cognism: ${endpoint} returned 405, trying next endpoint...`);
            continue;
          }

          if (redeemResponse.status === 429) {
            throw new Error("Rate limit exceeded on redeem - please try again later");
          }

          if (!redeemResponse.ok) {
            const errorText = await redeemResponse.text();
            console.error(`Cognism redeem error on ${endpoint} (${redeemResponse.status}): ${errorText}`);
            continue;
          }

          redeemData = await redeemResponse.json();
          console.log('Cognism: Successfully redeemed contact data from', endpoint);
          break;
        } catch (error) {
          console.error(`Cognism: Failed to redeem from ${endpoint}:`, error);
          continue;
        }
      }

      // If redeem failed, try GET method as fallback
      if (!redeemData) {
        try {
          console.log('Cognism: Trying GET method for redeem as fallback...');
          const params = new URLSearchParams({ contactIds: contactIds.join(',') });
          const redeemResponse = await fetch(`https://app.cognism.com/api/redeem/contacts?${params}`, {
            method: 'GET',
            headers: {
              'Authorization': `Bearer ${apiKey}`,
            },
          });

          if (redeemResponse.ok) {
            redeemData = await redeemResponse.json();
            console.log('Cognism: Successfully redeemed with GET method');
          }
        } catch (error) {
          console.error('Cognism: GET redeem also failed:', error);
        }
      }

      // If we still don't have redeem data, return empty
      if (!redeemData) {
        console.log('Cognism: Could not redeem contact details, returning empty results');
        return { emails: [], mobilePhones: [] };
      }

      console.log('Cognism: Processing redeemed contact data');

      // Extract emails and phones from redeemed data
      const emails: string[] = [];
      const mobilePhones: string[] = [];

      // Parse the redeemed contacts
      const contacts = redeemData.contacts || redeemData.results || [];
      
      for (const contact of contacts) {
        // Extract emails
        if (contact.email) {
          emails.push(contact.email);
        }
        if (contact.emails && Array.isArray(contact.emails)) {
          for (const email of contact.emails) {
            if (typeof email === 'string') {
              emails.push(email);
            } else if (email.email) {
              emails.push(email.email);
            }
          }
        }
        
        // Extract mobile phones
        if (contact.mobilePhone) {
          mobilePhones.push(contact.mobilePhone);
        }
        if (contact.mobilePhoneNumbers && Array.isArray(contact.mobilePhoneNumbers)) {
          for (const phone of contact.mobilePhoneNumbers) {
            if (typeof phone === 'string') {
              mobilePhones.push(phone);
            } else if (phone.number) {
              mobilePhones.push(phone.number);
            } else if (phone.phone) {
              mobilePhones.push(phone.phone);
            }
          }
        }
        if (contact.phoneNumbers && Array.isArray(contact.phoneNumbers)) {
          for (const phone of contact.phoneNumbers) {
            // Filter for mobile phones only
            if (phone.type === 'mobile' || phone.isMobile) {
              if (typeof phone === 'string') {
                mobilePhones.push(phone);
              } else if (phone.number) {
                mobilePhones.push(phone.number);
              } else if (phone.phone) {
                mobilePhones.push(phone.phone);
              }
            }
          }
        }
      }

      // Remove duplicates
      return {
        emails: Array.from(new Set(emails)),
        mobilePhones: Array.from(new Set(mobilePhones)),
      };
    } catch (error) {
      console.error('Cognism enrichment error:', error);
      // Return empty arrays on failure (graceful degradation)
      if (error instanceof Error && error.message.includes('authentication')) {
        throw error; // Re-throw authentication errors
      }
      return { emails: [], mobilePhones: [] };
    }
  });
}

// Clay.io API
async function enrichWithClay(contact: Contact): Promise<EnrichmentData> {
  const apiKey = process.env.CLAY_API_KEY;
  if (!apiKey) {
    throw new Error("Clay API key not configured");
  }

  await rateLimiter.throttle('clay');

  return retryWithBackoff(async () => {
    const response = await fetch('https://api.clay.com/v1/enrichment/person', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        first_name: contact.firstname,
        last_name: contact.lastname,
        email: contact.emailaddress1,
        linkedin_url: contact.new_linkedinprofile,
      }),
    });

    if (response.status === 429) {
      throw new Error("Rate limit exceeded - please try again later");
    }

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Clay API error (${response.status}): ${errorText}`);
    }

    const data: any = await response.json();
    
    return {
      emails: data.emails || [],
      mobilePhones: data.phone_numbers?.filter((p: any) => p.type === 'mobile').map((p: any) => p.number) || [],
    };
  });
}

// Provider registry
const PROVIDER_FUNCTIONS: Record<Provider, (contact: Contact) => Promise<EnrichmentData>> = {
  apollo: enrichWithApollo,
  bettercontact: enrichWithBetterContact,
  fullenrich: enrichWithFullEnrich,
  cognism: enrichWithCognism,
  clay: enrichWithClay,
};

export async function enrichWithProvider(
  provider: Provider,
  contact: Contact
): Promise<EnrichmentData> {
  const enrichFn = PROVIDER_FUNCTIONS[provider];
  if (!enrichFn) {
    throw new Error(`Unknown provider: ${provider}`);
  }
  return enrichFn(contact);
}

export async function enrichForceAll(
  contact: Contact,
  providers: Provider[]
): Promise<Map<Provider, { data?: EnrichmentData; error?: string }>> {
  const results = new Map<Provider, { data?: EnrichmentData; error?: string }>();
  
  // Run all providers in parallel
  const promises = providers.map(async (provider) => {
    try {
      const data = await enrichWithProvider(provider, contact);
      results.set(provider, { data });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error(`Provider ${provider} failed:`, errorMessage);
      results.set(provider, { error: errorMessage });
    }
  });

  await Promise.all(promises);
  return results;
}

export async function enrichWaterfall(
  contact: Contact,
  providers: Provider[]
): Promise<{ provider: Provider; data: EnrichmentData } | null> {
  // Try providers sequentially until one succeeds
  for (const provider of providers) {
    try {
      const data = await enrichWithProvider(provider, contact);
      if (data.emails.length > 0 || data.mobilePhones.length > 0) {
        return { provider, data };
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error(`Waterfall ${provider} failed:`, errorMessage);
      // Continue to next provider
    }
  }
  return null;
}
