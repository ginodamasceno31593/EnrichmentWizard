/**
 * ClearOutPhone API Client
 * Validates phone numbers using the ClearOutPhone API
 */

interface ClearOutPhoneResponse {
  status: string;
  phone_number?: string;
  valid?: boolean;
  line_type?: string;
  carrier?: string;
  location?: string;
  [key: string]: any;
}

/**
 * Validate a phone number using ClearOutPhone API
 * @param phoneNumber - The phone number to validate
 * @returns Object containing isValid boolean and optional details
 */
export async function validatePhoneNumber(
  phoneNumber: string
): Promise<{ isValid: boolean; details?: any }> {
  const apiKey = process.env.CLEAROUTPHONE_API_KEY;

  if (!apiKey) {
    console.warn('CLEAROUTPHONE_API_KEY not set, returning mock validation');
    // Return mock validation in development
    return {
      isValid: true,
      details: {
        phone_number: phoneNumber,
        line_type: 'mobile',
        carrier: 'Mock Carrier',
        status: 'valid',
      },
    };
  }

  try {
    const response = await fetch('https://api.clearoutphone.io/v1/phonenumber/validate', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        phone: phoneNumber,
      }),
    });

    if (!response.ok) {
      throw new Error(`ClearOutPhone API error: ${response.status} ${response.statusText}`);
    }

    const data: ClearOutPhoneResponse = await response.json();

    // Determine if phone is valid based on API response
    const isValid = data.valid === true || data.status === 'valid';

    return {
      isValid,
      details: data,
    };
  } catch (error) {
    console.error('ClearOutPhone validation error:', error);
    
    // Return mock validation as fallback
    return {
      isValid: true,
      details: {
        phone_number: phoneNumber,
        line_type: 'mobile',
        status: 'valid',
        error: error instanceof Error ? error.message : 'Validation service unavailable',
      },
    };
  }
}
