import { z } from "zod";
import { pgTable, text, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";

// Contact data from PowerApps
export const contactSchema = z.object({
  fullname: z.string(),
  firstname: z.string().optional(),
  lastname: z.string().optional(),
  emailaddress1: z.string().email().optional(),
  mobilephone: z.string().optional(),
  parentcustomerid: z.string().optional(),
  new_linkedinprofile: z.string().url().optional(),
});

export type Contact = z.infer<typeof contactSchema>;

// Enrichment result from a provider
export const enrichmentResultSchema = z.object({
  provider: z.enum(['apollo', 'bettercontact', 'fullenrich', 'cognism', 'clay']),
  status: z.enum(['pending', 'loading', 'success', 'error', 'no_results']),
  emails: z.array(z.string()).default([]),
  mobilePhones: z.array(z.string()).default([]),
  error: z.string().optional(),
  timestamp: z.string().optional(),
});

export type EnrichmentResult = z.infer<typeof enrichmentResultSchema>;

// Executive Assistant search result
export const executiveAssistantSchema = z.object({
  name: z.string(),
  email: z.string().email().optional(),
  phone: z.string().optional(),
  confidence: z.number().min(0).max(1).optional(),
});

export type ExecutiveAssistant = z.infer<typeof executiveAssistantSchema>;

// Enrichment mode
export type EnrichmentMode = 'force_all' | 'waterfall' | 'select_source';

// API request/response schemas
export const enrichContactRequestSchema = z.object({
  contact: contactSchema,
  mode: z.enum(['force_all', 'waterfall', 'select_source']),
  providers: z.array(z.enum(['apollo', 'bettercontact', 'fullenrich', 'cognism', 'clay'])).optional(),
});

export type EnrichContactRequest = z.infer<typeof enrichContactRequestSchema>;

export const enrichContactResponseSchema = z.object({
  results: z.array(enrichmentResultSchema),
});

export type EnrichContactResponse = z.infer<typeof enrichContactResponseSchema>;

export const searchExecutiveAssistantRequestSchema = z.object({
  contact: contactSchema,
});

export type SearchExecutiveAssistantRequest = z.infer<typeof searchExecutiveAssistantRequestSchema>;

export const searchExecutiveAssistantResponseSchema = z.object({
  assistant: executiveAssistantSchema.optional(),
  error: z.string().optional(),
});

export type SearchExecutiveAssistantResponse = z.infer<typeof searchExecutiveAssistantResponseSchema>;

// Phone Number entity for Dataverse (cr533_phonenumbers)
// Drizzle table definition
export const phoneNumberTable = pgTable('cr533_phonenumbers', {
  cr533_phonenumbersid: text('cr533_phonenumbersid').primaryKey(),
  cr533_phonenumber: text('cr533_phonenumber').notNull(),
  cr533_relatedcontact: text('cr533_relatedcontact').notNull(),
  cr533_isvalidated: boolean('cr533_isvalidated').notNull(),
  cr533_validationstatus: text('cr533_validationstatus', { enum: ['valid', 'invalid', 'pending'] }).notNull(),
});

// Drizzle-zod schemas
export const insertPhoneNumberSchema = createInsertSchema(phoneNumberTable).omit({
  cr533_phonenumbersid: true,
});

export type InsertPhoneNumber = z.infer<typeof insertPhoneNumberSchema>;
export type PhoneNumber = typeof phoneNumberTable.$inferSelect;

// Phone validation request/response
export const validatePhoneRequestSchema = z.object({
  phoneNumber: z.string(),
});

export type ValidatePhoneRequest = z.infer<typeof validatePhoneRequestSchema>;

export const validatePhoneResponseSchema = z.object({
  isValid: z.boolean(),
  details: z.any().optional(),
});

export type ValidatePhoneResponse = z.infer<typeof validatePhoneResponseSchema>;
