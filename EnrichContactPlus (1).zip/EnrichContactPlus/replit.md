# Contact Enrichment Web Resource

## Overview

This is a contact enrichment tool designed as an embedded web resource for Microsoft PowerApps model-driven apps. It is embedded within the "Enrichments" tab of the Contact form, automatically loading contact data from the form context. Users can enrich contact information by fetching emails and mobile phone numbers from multiple third-party data providers (Apollo.io, BetterContact, FullEnrich, Cognism, and Clay.io). The application also includes an AI-powered Executive Assistant search feature using OpenAI's GPT-5 model.

The system is built as a full-stack web application with a React frontend and Express backend, designed to integrate seamlessly within the PowerApps Contact form while following Microsoft's Fluent Design principles.

**Key Features:**
- Auto-loads contact data from PowerApps form context (Xrm.Page.data.entity)
- Embedded in "Enrichments" tab of Contact form in model-driven apps
- Three enrichment modes: Force Run All (parallel), Waterfall (sequential), and Select Specific Sources
- Real-time enrichment from six data providers with rate limiting and retry logic (Apollo, BetterContact, FullEnrich, Cognism, Clay, ClearOutPhone)
- Phone number validation using ClearOutPhone API with visual status indicators (green check/red X)
- Phone Numbers table management - add enriched phones to cr533_phonenumbers entity via Dataverse
- Aircall click-to-dial integration for added phone numbers with call count tracking per Aircall number
- Dataverse-backed caching layer with 60-minute TTL to reduce redundant API calls
- Force Refresh option to bypass cache when needed
- Cache age indicators showing data freshness in UI
- AI-powered Executive Assistant search using OpenAI GPT-5
- Enrichment history tracking with Dataverse storage
- **Ultra-compact UI design optimized to fit in 400px × 300px PowerApps form tab section**
- **All sections collapsible to maximize space usage**
- **Production-ready with development UI elements hidden in PowerApps context**

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System:**
- React 18 with TypeScript for type safety
- Vite as the build tool and development server
- Wouter for client-side routing (lightweight alternative to React Router)

**UI Component Library:**
- Radix UI primitives for accessible, unstyled components
- shadcn/ui component system (New York variant) for pre-styled components
- Tailwind CSS for styling with custom design tokens
- Microsoft Fluent Design principles (Segoe UI typography, specific spacing system)

**State Management:**
- TanStack Query (React Query) for server state management and API requests
- React Hook Form with Zod validation for all form state (ContactInputForm uses shadcn Form component with useForm hook and zodResolver)
- Local component state with React hooks

**Design System:**
- Custom Tailwind configuration aligned with Fluent Design
- Typography scale: 11px to 24px with specific font weights (300-700)
- Spacing primitives based on Tailwind units (2, 3, 4, 6, 8)
- Custom color system with CSS variables for light/dark mode support
- Border radius system: 2px (sm), 4px (md), 8px (lg) matching Fluent Design

### Backend Architecture

**Server Framework:**
- Express.js with TypeScript
- ESM module system
- Development and production build separation using esbuild

**API Design:**
- RESTful endpoints under `/api` prefix
- Request/response validation using Zod schemas
- Centralized error handling and logging middleware
- Session-based request logging with response tracking

**Key Endpoints:**
- `POST /api/enrich` - Contact enrichment with configurable modes
- `POST /api/search-ea` - Executive Assistant search using AI

**Enrichment Modes:**
1. **Force All**: Runs all providers in parallel, returns all results
2. **Waterfall**: Runs providers sequentially, stops at first success
3. **Select Source**: Runs only user-selected providers

**Rate Limiting & Resilience:**
- Custom RateLimiter class with 1-second minimum delay between provider calls
- Retry logic with exponential backoff (retryWithBackoff helper, 2 attempts, base delay 1000ms)
- Graceful error handling per provider with clear user feedback via toast notifications
- All provider integrations use node-fetch with proper error handling

### Data Storage Solutions

**Architecture:**
- **Client-Side Web Resource**: React application builds to static HTML/JS/CSS for upload to Dataverse as web resources
- **API Proxy Backend**: Express server serves as secure proxy for third-party API calls (Apollo, BetterContact, etc.) to prevent API key exposure
- **Dataverse Storage**: All persistent data stored in Dataverse custom tables via Web API

**Dataverse Tables (Custom Entities):**
- `new_enrichmenthistory` - Stores enrichment attempt history per contact
- `new_enrichmentcache` - Caches recent enrichment results with TTL
- `new_auditlog` - Tracks all enrichment operations and results
- `cr533_phonenumbers` - Stores validated phone numbers linked to contacts via cr533_relatedcontact lookup

**Data Models:**
- Contact schema (from PowerApps Contact entity)
- Enrichment result schema
- Executive Assistant schema
- No local database - all persistence through Dataverse Web API

### Authentication and Authorization

**Current State:**
- Basic user storage interface defined
- No active authentication implemented
- Session management prepared (connect-pg-simple for future use)

**Design Considerations:**
- Built for embedded PowerApps context where authentication may be handled by parent application
- User storage interface supports future extension with database-backed authentication

### External Dependencies

**Third-Party Enrichment Providers:**
1. **Apollo.io** - B2B contact database
2. **BetterContact** - Email enrichment service
3. **FullEnrich** - Complete data enrichment
4. **Cognism** - International contact data provider
5. **Clay.io** - Enrichment waterfall service

All providers require API keys stored in environment variables:
- `APOLLO_API_KEY`
- `BETTERCONTACT_API_KEY`
- `FULLENRICH_API_KEY`
- `COGNISM_API_KEY`
- `CLAY_API_KEY`
- `CLEAROUTPHONE_API_KEY`

**AI Services:**
- **OpenAI GPT-5** - Executive Assistant search functionality
- Environment variable: `OPENAI_API_KEY`
- Model: `gpt-5` (configured as latest model as of August 2025)
- Response validation using strict Zod schema for data integrity

**Dataverse Web API:**
- All data persistence uses Dataverse custom tables
- Web resource authenticates using parent PowerApps context
- Backend proxy does NOT store data - only forwards API calls
- Custom entities store enrichment history, audit logs, and cache

**Development Tools:**
- Replit-specific plugins for development experience
- Runtime error modal overlay
- Cartographer and dev banner (development only)

**CSS & Styling:**
- PostCSS with Tailwind CSS and Autoprefixer
- Google Fonts (Segoe UI web font)

**Form Validation:**
- Zod for schema validation
- @hookform/resolvers for React Hook Form integration
- drizzle-zod for database schema validation